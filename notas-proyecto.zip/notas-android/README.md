# y37x 1.1.0 · Inicio con notas

Al abrir la aplicación se muestra un bloc de notas negro y verde. El menú anterior de fotos, videos y privacidad se conserva detrás de un código de entrada.

## Uso

1. Abre **Ajustes adicionales → Crear contraseña**. Escribe y confirma entre 6 y 12 dígitos.
2. Vuelve y crea o edita una nota. Escribe únicamente ese código en el cuerpo y pulsa **Enter** o **Guardar**. No añadas espacios ni saltos de línea.
3. El código se borra del editor sin guardarlo como nota y aparece el menú anterior.
4. Los demás textos se guardan con **Guardar**. Las notas pueden abrirse y editarse.
5. Al dejar la aplicación en segundo plano, se cierra el acceso al menú y se bloquea la bóveda. Al volver se muestran las notas.
6. Para cambiar el código de entrada, introduce primero el actual en Ajustes adicionales.

El código de entrada es independiente del PIN o patrón de la bóveda. No cambia claves ni permite restablecer el cifrado de archivos anteriores. La configuración original de la bóveda permanece dentro del menú privado. Las notas normales se almacenan localmente sin cifrado; no son parte de la bóveda.

No desinstales para actualizar: las notas y las credenciales locales se eliminan al desinstalar. Conserva las copias cifradas y la clave de recuperación de la bóveda según las instrucciones originales. No existe recuperación del código de entrada en esta versión.

## Estado de verificación de esta modificación

Se han añadido pruebas instrumentadas para la persistencia de notas, rechazo de códigos incorrectos, cambio de código con autenticación y separación de las claves de la bóveda. **No se han ejecutado ni se ha generado un APK en este entorno**: no está disponible Gradle ni el SDK de Android. Requiere compilar y probar en un dispositivo o emulador antes de usar archivos importantes.

Pruebas manuales pendientes: guardar y editar notas; código correcto por Enter y Guardar; texto numérico incorrecto como nota; retorno a notas al salir; inicio después de cerrar el proceso; cambio de código; acceso y recuperación de la bóveda anterior. Los selectores de archivos externos pueden provocar el bloqueo al salir de la app: comprueba ese flujo en el dispositivo.

Compilación con Android Studio o Gradle 8.10.2 y SDK 35:

```sh
gradle :app:assembleDebug :app:testDebugUnitTest
# Con un dispositivo/emulador conectado:
gradle :app:connectedDebugAndroidTest
```

APK de prueba esperado: `app/build/outputs/apk/debug/app-debug.apk`. Una actualización instalada debe tener el mismo identificador de paquete y certificado que la instalación anterior.

---

## Documentación original del proyecto recibido

# y37x — Android

Proyecto nativo Android en Kotlin + Jetpack Compose. Identificador: `com.y37x.app`.

## Estado de entrega

Este paquete contiene el **proyecto fuente** y las pruebas automatizadas escritas para el núcleo criptográfico. En el entorno donde se preparó el proyecto no están instalados Android SDK, Android Build Tools ni Gradle, y no hay acceso de red para descargarlos. Por ese motivo **no se ha podido compilar ni ejecutar la aplicación Android aquí** y no se adjunta un APK ficticio. La compilación y las pruebas de dispositivo deben hacerse en Android Studio siguiendo las instrucciones inferiores.

## Funciones incluidas en el código

- Interfaz oscura, verde esmeralda y navegación inferior.
- Galería de fotos JPG/JPEG/PNG consultada mediante MediaStore, con cuadrícula, selección múltiple, visor, información y eliminación con confirmación del sistema.
- Galería independiente de videos, miniaturas de fotograma, duración/tamaño y reproducción integrada mediante Media3.
- Bóveda PRIVACIDAD con PIN de 6–12 dígitos o patrón de 4 o más puntos.
- AES-256-GCM para cada archivo y sus metadatos. El archivo se descifra a un temporal privado para verificar el tag GCM y comparar SHA-256 antes de ofrecer la eliminación del original.
- Clave maestra aleatoria de 256 bits. El envoltorio local se deriva mediante PBKDF2-HMAC-SHA256 y se combina con una clave HMAC no exportable de Android Keystore.
- La clave de recuperación independiente es aleatoria de 256 bits y se muestra una sola vez durante la configuración. Se presenta en hexadecimal de 64 caracteres.
- Los archivos de la bóveda se almacenan en `noBackupFilesDir`, con nombres aleatorios; metadatos cifrados en Room. No se publican en MediaStore.
- FLAG_SECURE en la bóveda, visor privado y pantalla que muestra la clave de recuperación. Los temporales descifrados se eliminan al cerrar el visor y se limpian al iniciar la aplicación.
- Copias ZIP con contenido multimedia cifrado, metadatos cifrados y envoltorio cifrado de la clave maestra.
- WorkManager para respaldos automáticos cada 24 horas en una carpeta que el usuario autoriza mediante el selector de documentos de Android.
- Restauración que verifica la clave de recuperación, autentica todos los archivos GCM y vuelve a envolver **la misma clave maestra** con un PIN nuevo.
- Limitación progresiva de intentos incorrectos de desbloqueo.

## Requisitos de compilación

- Android Studio Ladybug o posterior.
- JDK 17.
- Gradle 8.10.2.
- Android SDK Platform 35 y Build Tools 35.x.
- Dispositivo Android 8.0 (API 26) o posterior.

## Abrir y compilar

1. Descomprime el proyecto.
2. En Android Studio, selecciona **Open** y abre la carpeta `y37x-android`.
3. Instala Android SDK Platform 35 si Android Studio lo solicita.
4. Configura Gradle JDK en JDK 17 y espera a que termine la sincronización.
5. Si quieres generar el wrapper estándar en tu entorno, ejecuta `gradle wrapper --gradle-version 8.10.2` desde la raíz; después puedes usar `./gradlew`.
6. Ejecuta las pruebas unitarias:

   ```bash
   gradle :app:testDebugUnitTest
   ```

7. Para generar el APK de pruebas:

   ```bash
   gradle :app:assembleDebug
   ```

   Resultado esperado: `app/build/outputs/apk/debug/app-debug.apk`.
   El paquete debug usa el identificador `com.y37x.app.debug`.

8. Para generar el APK release sin firmar:

   ```bash
   gradle :app:assembleRelease
   ```

   Resultado esperado: `app/build/outputs/apk/release/app-release-unsigned.apk`.

`build.sh` ejecuta los dos ensamblados y las pruebas unitarias si Gradle 8.10.2 está instalado y disponible en PATH.

## Firmar el APK release

No se incluye una clave privada de firma compartida. Crea una propia y guárdala fuera del repositorio:

```bash
keytool -genkeypair -v \
  -keystore y37x-release.jks \
  -keyalg RSA -keysize 4096 -validity 10000 \
  -alias y37x
```

Alinea y firma el APK (usa `apksigner` del Android SDK Build Tools):

```bash
zipalign -p -f 4 \
  app/build/outputs/apk/release/app-release-unsigned.apk \
  app-release-aligned.apk

apksigner sign --ks y37x-release.jks --ks-key-alias y37x \
  --out y37x-release.apk app-release-aligned.apk

apksigner verify --verbose --print-certs y37x-release.apk
```

Conserva la clave `.jks` y sus contraseñas en un lugar seguro. Si se pierde, no podrás publicar actualizaciones firmadas con la misma identidad.

## Configurar Google Drive

Esta implementación utiliza el **Storage Access Framework (SAF) de Android**, no una integración REST directa con Google Drive. El proveedor de Google Drive aparece en el selector de carpetas de Android cuando está instalado y la cuenta está iniciada. El proveedor gestiona la autorización; no hace falta crear un proyecto OAuth ni incrustar un secreto de cliente en la aplicación.

1. Instala Google Drive e inicia sesión en la cuenta que usará las copias.
2. Abre y37x → Configuración → Copias de seguridad.
3. Pulsa **Elegir carpeta de respaldo**.
4. En el selector de Android, elige Google Drive y selecciona una carpeta. Concede el acceso solicitado.
5. y37x crea una copia inmediata y programa respaldos periódicos de 24 horas con WorkManager. Android puede retrasar la ejecución por ahorro de batería o falta de conectividad.
6. Para restaurar, pulsa **Seleccionar copia para restaurar**, elige el ZIP en Drive, introduce la clave de recuperación y define un PIN nuevo.

La copia se publica como `y37x-backup-<timestamp>.zip`. Antes de eliminar copias anteriores, el worker vuelve a leer el archivo del proveedor y compara su SHA-256 con el ZIP local. La aplicación elimina copias anteriores con ese prefijo solo después de esa verificación. El archivo ZIP contiene archivos ya cifrados y metadatos cifrados; las fotografías y videos en claro no se suben.

## Recuperación y pérdida de clave

- La cuenta Google solo permite localizar/descargar la copia. **No descifra** la bóveda.
- La clave de recuperación de 64 caracteres es necesaria para recuperar la clave maestra original desde la copia.
- Si se desinstala la aplicación, se pierde el almacenamiento local y la clave de Android Keystore de esa instalación. Se reinstala, se descarga la copia y se restaura con la clave de recuperación.
- Si se pierde la clave de recuperación y no existe otra copia válida de esa clave, los archivos cifrados son irrecuperables. No existe una puerta trasera.
- La clave de recuperación no se guarda en texto plano en la aplicación. Debe anotarse o guardarse en un gestor de contraseñas independiente.

## Pruebas

- `CryptoEngineTest`: cifrado/descifrado de un flujo de 1,5 MB, comparación SHA-256 y rechazo de ciphertext alterado o clave incorrecta.
- `VaultKeyManagerInstrumentedTest`: envoltorio local con Android Keystore, rechazo de PIN incorrecto y recuperación del mismo master key con la clave independiente.
- Ejecuta las pruebas instrumentadas en un emulador/dispositivo desde Android Studio: **Run > Run 'app'** en `app/src/androidTest`.

## Validación pendiente antes de distribuir

La fuente está preparada, pero esta entrega no puede afirmar una compilación o prueba real de interfaz porque no se dispuso de Android SDK/Gradle ni de un dispositivo/emulador. Antes de distribuir, compila en Android Studio y prueba como mínimo:

1. Permisos completos y parciales de fotos en Android 14/15.
2. Importación de fotos y videos grandes, verificación y cancelación de borrado original.
3. Reproducción de videos con los códecs del dispositivo.
4. PIN y patrón, bloqueo tras intentos fallidos y bloqueo de capturas.
5. Copia manual y periódica a una carpeta de Google Drive con el dispositivo conectado y desconectado.
6. Desinstalación/reinstalación y restauración en otro dispositivo con la clave de recuperación.
7. Recuperación ante ZIP corrupto, clave incorrecta, falta de espacio y revocación de permisos del proveedor.

La protección hardware-backed de Android Keystore depende del dispositivo. `FLAG_SECURE` reduce capturas de pantalla y grabaciones del sistema, pero no protege frente a un dispositivo rooteado, firmware comprometido o una cámara externa.
