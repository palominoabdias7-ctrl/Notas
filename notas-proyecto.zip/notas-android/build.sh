#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.10.2 is required. Open this folder in Android Studio or install Gradle 8.10.2."
  exit 1
fi
gradle --version
gradle :app:assembleDebug :app:assembleRelease :app:testDebugUnitTest
