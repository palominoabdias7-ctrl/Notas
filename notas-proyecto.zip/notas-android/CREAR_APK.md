# Crear el APK desde GitHub

Este proyecto incluye `.github/workflows/apk.yml`. La compilación aún no se ha ejecutado.

1. Extrae el ZIP en el teléfono.
2. En github.com, crea un repositorio llamado Notas. Puedes hacerlo privado. Activa la creación de un README para poder subir archivos desde el navegador.
3. Sube el CONTENIDO de la carpeta notas-android al repositorio. En la raíz deben quedar app/, build.gradle.kts, settings.gradle.kts y los demás archivos. No subas solo el ZIP: GitHub no lo descomprime. No dejes todo dentro de otra carpeta notas-android.
4. Si tu navegador no permite subir carpetas, sube cada carpeta desde su ubicación correspondiente, o usa el editor web de GitHub. La estructura de carpetas debe conservarse.
5. Si no se ha subido la carpeta oculta .github, pulsa Add file → Create new file. Escribe como nombre `.github/workflows/apk.yml` y copia exactamente el contenido del archivo apk.yml de este ZIP. Guarda con Commit changes en main.
6. En Actions, abre Crear APK Notas. El guardado en main inicia una compilación; también puedes usar Run workflow.
7. Cuando termine con una marca verde, entra en la ejecución y busca Artifacts → Notas-apk. Debes estar conectado a tu cuenta para descargarlo. Extrae ese ZIP: contiene Notas.apk.
8. Abre Notas.apk en Android y permite instalar desde ese navegador o gestor de archivos cuando el teléfono lo solicite.

Si falla, abre el paso rojo y comparte su mensaje de error. No se ha probado el resultado en un teléfono todavía.

El resultado es un APK debug firmado automáticamente para pruebas, no una versión de publicación. No desinstales una versión que contenga archivos sin un respaldo recuperable. Para actualizar una app existente se requiere el mismo paquete y certificado; las compilaciones debug en distintos ejecutores pueden usar certificados distintos. Antes de usarla de forma permanente, configura una clave de firma propia y estable.
