# Modelo de seguridad y formato de datos de y37x

## Jerarquía de claves

- Master key: 32 bytes aleatorios, generados con `SecureRandom`.
- Cifrado de medios y metadatos: AES/GCM/NoPadding, clave de 256 bits, nonce aleatorio de 96 bits, tag de 128 bits y AAD asociado al identificador aleatorio del elemento.
- Envoltura local: PBKDF2-HMAC-SHA256 (310 000 iteraciones, salt de 16 bytes) + HMAC-SHA256 con una clave no exportable del Android Keystore. El resultado de 256 bits envuelve la master key con AES-256-GCM.
- Recuperación: clave independiente de 32 bytes aleatorios. Envuelve la misma master key con AES-256-GCM y AAD `y37x-recovery-master-v1`. Solo se muestra como 64 caracteres hexadecimales.

## Archivo de medios

`Y37X | version(1) | nonce(12) | ciphertext | GCM tag(16)`.
La autenticación GCM se comprueba al llegar al EOF. La importación descifra a un temporal privado, comprueba el tag y compara SHA-256 con el original antes de registrar el elemento.

## Copia

El ZIP incluye un manifiesto con identificadores aleatorios, metadatos ya cifrados y el envoltorio de recuperación cifrado, además de los archivos `.y37x` cifrados. No incluye nombres originales ni MIME en claro. La restauración limita el número/tamaño de entradas, rechaza rutas inesperadas, valida metadatos y autentica cada archivo antes de instalarlo.

## Consideraciones

- La clave local de Android Keystore no migra al reinstalar ni a otro teléfono; se crea un nuevo envoltorio local después de restaurar con la clave de recuperación.
- La clave de recuperación no se puede regenerar sin una master key ya desbloqueada y una copia válida. La versión actual la muestra al crear la bóveda y la incluye envuelta en las copias posteriores.
- WorkManager copia los blobs cifrados; no necesita desbloquear ni conocer la master key.
- Los archivos de vista previa se descifran temporalmente en caché privada y se eliminan al cerrar el visor; se eliminan residuos al iniciar la app.
- El borrado de los originales usa el diálogo de confirmación del sistema cuando está disponible.
