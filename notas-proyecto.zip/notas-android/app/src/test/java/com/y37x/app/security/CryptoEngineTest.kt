package com.y37x.app.security

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class CryptoEngineTest {
    @Test
    fun streamEncryptionRoundTripsAndAuthenticates() {
        val plain = ByteArray(1_500_000) { (it % 251).toByte() }
        val key = CryptoEngine.randomBytes(32)
        val aad = "media-id".toByteArray()
        val encrypted = ByteArrayOutputStream()
        val sourceHash = CryptoEngine.encryptStream(ByteArrayInputStream(plain), encrypted, key, aad)
        val decrypted = ByteArrayOutputStream()
        val recoveredHash = CryptoEngine.decryptStream(ByteArrayInputStream(encrypted.toByteArray()), decrypted, key, aad)
        assertArrayEquals(plain, decrypted.toByteArray())
        assertArrayEquals(sourceHash, recoveredHash)
    }

    @Test
    fun wrongKeyOrModifiedCiphertextIsRejected() {
        val key = CryptoEngine.randomBytes(32)
        val aad = "item-1".toByteArray()
        val encrypted = CryptoEngine.encryptBytes("private".toByteArray(), key, aad)
        assertThrows(Exception::class.java) {
            CryptoEngine.decryptBytes(encrypted, CryptoEngine.randomBytes(32), aad)
        }
        val modified = encrypted.copyOf().also { it[it.lastIndex] = (it.last().toInt() xor 1).toByte() }
        assertThrows(Exception::class.java) { CryptoEngine.decryptBytes(modified, key, aad) }
    }
}
