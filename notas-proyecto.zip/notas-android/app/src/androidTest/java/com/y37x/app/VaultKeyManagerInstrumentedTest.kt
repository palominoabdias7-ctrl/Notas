package com.y37x.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.y37x.app.security.CryptoEngine
import com.y37x.app.security.KeyManager
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class VaultKeyManagerInstrumentedTest {
    @Test
    fun localKeystoreEnvelopeRequiresTheCorrectCredential() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.getSharedPreferences("y37x_security", Context.MODE_PRIVATE).edit().clear().commit()
        val manager = KeyManager(context)
        val master = CryptoEngine.randomBytes(32)
        manager.saveLocalEnvelope(master, "123456", "PIN")
        assertArrayEquals(master, manager.unlock("123456"))
        assertThrows(Exception::class.java) { manager.unlock("654321") }
        context.getSharedPreferences("y37x_security", Context.MODE_PRIVATE).edit().clear().commit()
    }

    @Test
    fun independentRecoveryKeyOpensTheSameMasterKey() {
        val master = CryptoEngine.randomBytes(32)
        val recoveryKey = CryptoEngine.randomBytes(32)
        val envelope = CryptoEngine.encryptBytes(master, recoveryKey, "y37x-recovery-master-v1".toByteArray())
        val recovered = CryptoEngine.decryptBytes(envelope, recoveryKey, "y37x-recovery-master-v1".toByteArray())
        assertArrayEquals(master, recovered)
        assertThrows(Exception::class.java) {
            CryptoEngine.decryptBytes(envelope, CryptoEngine.randomBytes(32), "y37x-recovery-master-v1".toByteArray())
        }
    }
}
