package com.y37x.app

import androidx.test.core.app.ApplicationProvider
import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.y37x.app.ui.NotesEntrance
import com.y37x.app.ui.NotesStore
import com.y37x.app.ui.SavedNote
import com.y37x.app.security.KeyManager
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NotesEntranceInstrumentedTest {
    @Test fun entranceDoesNotReplaceVaultAndRequiresPreviousCode() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.getSharedPreferences("y37x_notes_entrance", Context.MODE_PRIVATE).edit().clear().commit()
        val vaultBefore = KeyManager(context).snapshotLocalEnvelope()
        val entrance = NotesEntrance(context)
        assertFalse(entrance.isConfigured())
        assertTrue(runCatching { entrance.save("12345", "") }.isFailure)
        entrance.save("123456", "")
        assertTrue(NotesEntrance(context).verify("123456"))
        assertFalse(entrance.verify("987654"))
        assertTrue(runCatching { entrance.save("654321", "000000") }.isFailure)
        assertTrue(entrance.verify("123456"))
        entrance.save("654321", "123456")
        assertFalse(entrance.verify("123456"))
        assertTrue(entrance.verify("654321"))
        assertEquals(vaultBefore, KeyManager(context).snapshotLocalEnvelope())
        context.getSharedPreferences("y37x_notes_entrance", Context.MODE_PRIVATE).edit().clear().commit()
    }

    @Test fun notesSurviveRepositoryRecreationAndPreserveUnicode() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = NotesStore(context)
        val previous = store.load()
        try {
            val notes = listOf(SavedNote("note-test", "Prueba ñ", "Línea 1\nLínea 2 🌿"))
            store.save(notes)
            assertEquals(notes, NotesStore(context).load())
        } finally { store.save(previous) }
    }
}
