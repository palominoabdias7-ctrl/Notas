package com.y37x.app.backup

import android.content.Context
import android.util.Base64
import com.y37x.app.data.VaultDao
import com.y37x.app.vault.VaultRepository
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class BackupManager(
    private val context: Context,
    private val dao: VaultDao,
    private val vault: VaultRepository
) {
    suspend fun createArchive(destination: File) {
        val items = dao.getAll()
        require(vault.recoveryEnvelopeFile.exists()) { "No se encontró la clave de recuperación de esta bóveda" }
        val manifestItems = JSONArray()
        items.forEach { item ->
            manifestItems.put(
                JSONObject()
                    .put("id", item.id)
                    .put("fileName", item.fileName)
                    .put("encryptedMetadata", item.encryptedMetadata)
                    .put("addedAt", item.addedAt)
            )
        }
        val manifest = JSONObject()
            .put("schema", 1)
            .put("createdAt", System.currentTimeMillis())
            .put("recoveryEnvelope", Base64.encodeToString(vault.recoveryEnvelopeFile.readBytes(), Base64.NO_WRAP))
            .put("items", manifestItems)

        destination.parentFile?.mkdirs()
        ZipOutputStream(FileOutputStream(destination)).use { zip ->
            zip.putNextEntry(ZipEntry("manifest.json"))
            zip.write(manifest.toString().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            items.forEach { item ->
                val source = File(vault.vaultDirectory, item.fileName)
                require(source.exists() && source.length() >= 33L) { "Falta un archivo cifrado de la bóveda" }
                zip.putNextEntry(ZipEntry("files/${item.fileName}"))
                FileInputStream(source).use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
        require(destination.exists() && destination.length() > 0L) { "No se pudo crear la copia cifrada" }
        // Re-open the ZIP and check the complete entry set/CRC before publishing it.
        java.util.zip.ZipFile(destination).use { archive ->
            require(archive.getEntry("manifest.json") != null) { "Copia incompleta" }
            items.forEach { require(archive.getEntry("files/${it.fileName}") != null) { "Copia incompleta" } }
            val buffer = ByteArray(64 * 1024)
            val names = archive.entries().asSequence().map { it.name }.toSet()
            require(names.size == items.size + 1) { "La copia contiene entradas inesperadas" }
            names.forEach { name ->
                archive.getInputStream(archive.getEntry(name)).use { input -> while (input.read(buffer) >= 0) Unit }
            }
        }
    }

    companion object {
        const val PREFS = "y37x_backup"
        const val TREE_URI = "backup_tree_uri"
        const val LAST_BACKUP = "last_backup_at"
    }
}
