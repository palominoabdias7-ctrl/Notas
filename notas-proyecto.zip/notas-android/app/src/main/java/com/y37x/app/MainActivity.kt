package com.y37x.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.key
import com.y37x.app.ui.Y37xApp
import com.y37x.app.ui.Y37xTheme

class MainActivity : ComponentActivity() {
    private val session = mutableIntStateOf(0)

    override fun onStop() {
        (application as Y37xApplication).vault.lock()
        session.intValue++
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            Y37xTheme {
                key(session.intValue) {
                    Y37xApp((application as Y37xApplication).vault)
                }
            }
        }
    }
}
