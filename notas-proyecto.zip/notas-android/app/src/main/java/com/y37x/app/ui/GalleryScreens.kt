package com.y37x.app.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.app.RecoverableSecurityException
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.y37x.app.media.MediaEntry
import com.y37x.app.media.MediaRepository
import com.y37x.app.vault.VaultRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GalleryScreen(
    isVideo: Boolean,
    vault: VaultRepository,
    onOpen: (MediaEntry) -> Unit,
    onNeedPrivacy: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var entries by remember { mutableStateOf<List<MediaEntry>>(emptyList()) }
    var permissionGranted by remember { mutableStateOf(hasPermission(context, isVideo)) }
    var refresh by remember { mutableStateOf(0) }
    var status by remember { mutableStateOf("") }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showDeleteAfterMove by remember { mutableStateOf(false) }
    var pendingDeleteUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var infoEntry by remember { mutableStateOf<MediaEntry?>(null) }
    val selected = remember { mutableStateListOf<String>() }

    fun load() {
        scope.launch {
            entries = withContext(Dispatchers.IO) {
                if (isVideo) MediaRepository.loadVideos(context) else MediaRepository.loadImages(context)
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permissionGranted = hasPermission(context, isVideo)
        if (permissionGranted) load()
    }
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        if (it.resultCode == Activity.RESULT_OK) {
            selected.clear()
            status = "Archivos eliminados"
            load()
        }
    }

    LaunchedEffect(isVideo, refresh) {
        permissionGranted = hasPermission(context, isVideo)
        if (permissionGranted) load()
    }

    Column(Modifier.fillMaxSize().background(Y37xBackground)) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
            Text(if (isVideo) "Videos" else "Fotografías", style = MaterialTheme.typography.headlineMedium, color = Y37xText, fontWeight = FontWeight.Bold)
            Text("${entries.size} archivos · ordenados por fecha", color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
        }
        if (!permissionGranted) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(if (isVideo) Icons.Outlined.PlayCircle else Icons.Outlined.Lock, null, tint = Y37xGreen, modifier = Modifier.size(42.dp))
                Spacer(Modifier.height(12.dp))
                Text("Permiso de acceso necesario", color = Y37xText, fontWeight = FontWeight.Bold)
                Text("y37x necesita permiso para mostrar los archivos multimedia que elijas compartir con la aplicación.", color = Y37xMuted)
                Spacer(Modifier.height(16.dp))
                Button(onClick = {
                    val permissions = when {
                        Build.VERSION.SDK_INT >= 34 && !isVideo -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
                        Build.VERSION.SDK_INT >= 33 && isVideo -> arrayOf(Manifest.permission.READ_MEDIA_VIDEO)
                        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
                        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    }
                    permissionLauncher.launch(permissions)
                }) { Text("Conceder permiso") }
            }
        } else {
            if (selected.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${selected.size} seleccionados", color = Y37xText, modifier = Modifier.weight(1f))
                    TextButton(onClick = { showDeleteConfirm = true }) { Icon(Icons.Outlined.Delete, null); Text("Eliminar") }
                    TextButton(onClick = {
                        if (!vault.isUnlocked()) {
                            status = "Desbloquea la bóveda para guardar archivos privados"
                            onNeedPrivacy()
                        } else {
                            val selectedEntries = entries.filter { it.uri.toString() in selected }
                            scope.launch {
                                val copiedUris = mutableListOf<Uri>()
                                selectedEntries.forEach { entry ->
                                    runCatching { vault.importMedia(entry.uri) }
                                        .onSuccess { copiedUris += entry.uri }
                                }
                                status = "${copiedUris.size} de ${selectedEntries.size} archivos cifrados y verificados"
                                selected.clear()
                                if (copiedUris.isNotEmpty()) {
                                    pendingDeleteUris = copiedUris
                                    showDeleteAfterMove = true
                                }
                            }
                        }
                    }) { Icon(Icons.Outlined.Lock, null); Text("Privacidad") }
                }
            }
            if (entries.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (isVideo) "No se encontraron videos" else "No se encontraron fotografías", color = Y37xMuted)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(entries, key = { it.id }) { entry ->
                        MediaTile(
                            entry = entry,
                            selected = entry.uri.toString() in selected,
                            onClick = {
                                if (selected.isNotEmpty()) {
                                    if (entry.uri.toString() in selected) selected.remove(entry.uri.toString()) else selected.add(entry.uri.toString())
                                } else onOpen(entry)
                            },
                            onLongClick = {
                                if (entry.uri.toString() in selected) selected.remove(entry.uri.toString()) else selected.add(entry.uri.toString())
                            },
                            onInfo = { infoEntry = entry }
                        )
                    }
                }
            }
        }
        if (status.isNotBlank()) Text(status, color = Y37xGreen, modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp), style = MaterialTheme.typography.bodySmall)
    }


    if (showDeleteAfterMove) {
        AlertDialog(
            onDismissRequest = { showDeleteAfterMove = false; pendingDeleteUris = emptyList() },
            title = { Text("Copia privada verificada") },
            text = { Text("Se cifraron y verificaron ${pendingDeleteUris.size} archivo(s). ¿Quieres solicitar ahora la eliminación de los originales del dispositivo?") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteAfterMove = false
                    val uris = pendingDeleteUris
                    pendingDeleteUris = emptyList()
                    if (Build.VERSION.SDK_INT >= 30) {
                        val request = MediaStore.createDeleteRequest(context.contentResolver, uris)
                        deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
                    } else {
                        var removed = 0
                        var requested = false
                        for (uri in uris) {
                            try {
                                if (context.contentResolver.delete(uri, null, null) > 0) removed++
                            } catch (security: SecurityException) {
                                if (Build.VERSION.SDK_INT == 29 && security is RecoverableSecurityException) {
                                    deleteLauncher.launch(IntentSenderRequest.Builder(security.userAction.actionIntent.intentSender).build())
                                    requested = true
                                    break
                                }
                            }
                        }
                        if (!requested) {
                            status = "$removed originales eliminados"
                            refresh++
                        }
                    }
                }) { Text("Eliminar originales", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAfterMove = false; pendingDeleteUris = emptyList() }) { Text("Conservar originales") }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Eliminar archivos") },
            text = { Text("Se solicitará la confirmación del sistema para eliminar ${selected.size} archivo(s) del dispositivo.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    val uris = entries.filter { it.uri.toString() in selected }.map { it.uri }
                    if (Build.VERSION.SDK_INT >= 30) {
                        val request = MediaStore.createDeleteRequest(context.contentResolver, uris)
                        deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
                    } else {
                        var removed = 0
                        var permissionRequestLaunched = false
                        for (uri in uris) {
                            try {
                                if (context.contentResolver.delete(uri, null, null) > 0) removed++
                            } catch (security: SecurityException) {
                                if (Build.VERSION.SDK_INT == 29 && security is RecoverableSecurityException) {
                                    deleteLauncher.launch(IntentSenderRequest.Builder(security.userAction.actionIntent.intentSender).build())
                                    permissionRequestLaunched = true
                                    break
                                }
                            }
                        }
                        if (!permissionRequestLaunched) {
                            selected.clear()
                            status = "$removed archivos eliminados"
                            refresh++
                        }
                    }
                }) { Text("Continuar", color = Y37xGreen) }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancelar") } }
        )
    }

    infoEntry?.let { item ->
        AlertDialog(
            onDismissRequest = { infoEntry = null },
            title = { Text("Información del archivo") },
            text = {
                Column {
                    Text(item.name, color = Y37xText)
                    Text(item.mimeType, color = Y37xMuted)
                    Text(formatSize(item.size), color = Y37xMuted)
                    if (item.durationMs > 0) Text("Duración: ${formatDuration(item.durationMs)}", color = Y37xMuted)
                    Text(DateFormat.getDateTimeInstance().format(Date(item.dateAdded * 1000)), color = Y37xMuted)
                }
            },
            confirmButton = { TextButton(onClick = { infoEntry = null }) { Text("Cerrar") } }
        )
    }
}

private fun hasPermission(context: Context, isVideo: Boolean): Boolean {
    fun granted(permission: String) = ContextCompat.checkSelfPermission(context, permission) == android.content.pm.PackageManager.PERMISSION_GRANTED
    return when {
        Build.VERSION.SDK_INT >= 34 && !isVideo -> granted(Manifest.permission.READ_MEDIA_IMAGES) || granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 && isVideo -> granted(Manifest.permission.READ_MEDIA_VIDEO)
        Build.VERSION.SDK_INT >= 33 -> granted(Manifest.permission.READ_MEDIA_IMAGES)
        else -> granted(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MediaTile(entry: MediaEntry, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit, onInfo: () -> Unit) {
    Box(
        Modifier
            .aspectRatio(1f)
            .background(Y37xCard, RoundedCornerShape(10.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        if (entry.isVideo) VideoThumbnail(entry.uri) else AsyncImage(
            model = entry.uri,
            contentDescription = entry.name,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        if (entry.isVideo) {
            Icon(Icons.Outlined.PlayCircle, null, tint = Y37xText, modifier = Modifier.align(Alignment.Center).size(34.dp))
            Text(formatDuration(entry.durationMs), color = Y37xText, modifier = Modifier.align(Alignment.BottomStart).padding(5.dp), style = MaterialTheme.typography.labelSmall)
        }
        if (selected) {
            Box(Modifier.fillMaxSize().background(Y37xGreen.copy(alpha = 0.28f)))
            Icon(Icons.Outlined.CheckCircle, null, tint = Y37xGreen, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
        }
        TextButton(onClick = onInfo, modifier = Modifier.align(Alignment.BottomEnd).size(36.dp), contentPadding = PaddingValues(0.dp)) {
            Icon(Icons.Outlined.Info, null, tint = Y37xText, modifier = Modifier.size(17.dp))
        }
    }
}

@Composable
private fun VideoThumbnail(uri: Uri) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, uri) {
        value = withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                retriever.getFrameAtTime(0)
            } catch (_: Exception) {
                null
            } finally {
                runCatching { retriever.release() }
            }
        }
    }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    else Box(Modifier.fillMaxSize().background(Y37xCard))
}

@Composable
fun MediaViewerScreen(uri: Uri, isVideo: Boolean, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Y37xBackground)) {
        ScreenHeader(if (isVideo) "Reproductor" else "Fotografía", onBack = onBack)
        if (isVideo) VideoPlayer(uri, Modifier.fillMaxWidth().weight(1f))
        else AsyncImage(model = uri, contentDescription = null, modifier = Modifier.fillMaxSize().padding(8.dp), contentScale = ContentScale.Fit)
    }
}

@Composable
fun VideoPlayer(uri: Uri, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = false
        }
    }
    androidx.compose.runtime.DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { viewContext -> PlayerView(viewContext).apply { this.player = player; useController = true } },
        modifier = modifier
    )
}

private fun formatSize(bytes: Long): String = when {
    bytes >= 1024L * 1024L * 1024L -> String.format(Locale.getDefault(), "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
    bytes >= 1024L * 1024L -> String.format(Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024.0))
    bytes >= 1024L -> String.format(Locale.getDefault(), "%.0f KB", bytes / 1024.0)
    else -> "$bytes B"
}

private fun formatDuration(durationMs: Long): String {
    val total = durationMs / 1000
    return String.format(Locale.getDefault(), "%02d:%02d", total / 60, total % 60)
}
