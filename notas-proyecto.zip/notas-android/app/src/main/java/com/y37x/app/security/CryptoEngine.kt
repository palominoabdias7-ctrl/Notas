package com.y37x.app.security

import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** AES-256-GCM helpers. The file format is: magic(4), version(1), nonce(12), ciphertext+tag. */
object CryptoEngine {
    private val random = SecureRandom()
    private val magic = byteArrayOf(0x59, 0x33, 0x37, 0x58) // Y37X
    private const val VERSION: Byte = 1
    private const val NONCE_SIZE = 12
    private const val TAG_BITS = 128
    private const val BUFFER_SIZE = 64 * 1024

    fun randomBytes(size: Int): ByteArray = ByteArray(size).also(random::nextBytes)

    fun encryptBytes(plain: ByteArray, key: ByteArray, aad: ByteArray): ByteArray {
        val nonce = randomBytes(NONCE_SIZE)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, nonce))
        cipher.updateAAD(aad)
        val encrypted = cipher.doFinal(plain)
        return magic + byteArrayOf(VERSION) + nonce + encrypted
    }

    fun decryptBytes(encrypted: ByteArray, key: ByteArray, aad: ByteArray): ByteArray {
        require(encrypted.size >= magic.size + 1 + NONCE_SIZE + 16) { "Archivo cifrado incompleto" }
        require(encrypted.copyOfRange(0, 4).contentEquals(magic)) { "Formato de archivo no reconocido" }
        require(encrypted[4] == VERSION) { "Versión de cifrado no compatible" }
        val nonce = encrypted.copyOfRange(5, 5 + NONCE_SIZE)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, nonce))
        cipher.updateAAD(aad)
        return cipher.doFinal(encrypted, 5 + NONCE_SIZE, encrypted.size - 5 - NONCE_SIZE)
    }

    /** Encrypts a stream without loading the media file into memory. Returns SHA-256 of plaintext. */
    fun encryptStream(input: InputStream, output: OutputStream, key: ByteArray, aad: ByteArray): ByteArray {
        val nonce = randomBytes(NONCE_SIZE)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, nonce))
        cipher.updateAAD(aad)
        output.write(magic)
        output.write(byteArrayOf(VERSION))
        output.write(nonce)
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER_SIZE)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (count == 0) continue
            digest.update(buffer, 0, count)
            val encrypted = cipher.update(buffer, 0, count)
            if (encrypted != null && encrypted.isNotEmpty()) output.write(encrypted)
        }
        output.write(cipher.doFinal())
        output.flush()
        return digest.digest()
    }

    /** Decrypts a stream and verifies its GCM tag at EOF. Delete output if this throws. */
    fun decryptStream(input: InputStream, output: OutputStream, key: ByteArray, aad: ByteArray): ByteArray {
        val header = ByteArray(5 + NONCE_SIZE)
        readFully(input, header)
        require(header.copyOfRange(0, 4).contentEquals(magic)) { "Archivo privado inválido" }
        require(header[4] == VERSION) { "Versión de archivo no compatible" }
        val nonce = header.copyOfRange(5, header.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BITS, nonce))
        cipher.updateAAD(aad)
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER_SIZE)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (count == 0) continue
            val plain = cipher.update(buffer, 0, count)
            if (plain != null && plain.isNotEmpty()) {
                digest.update(plain)
                output.write(plain)
            }
        }
        val finalPlain = cipher.doFinal() // throws AEADBadTagException on tampering
        if (finalPlain.isNotEmpty()) {
            digest.update(finalPlain)
            output.write(finalPlain)
        }
        output.flush()
        return digest.digest()
    }

    private fun readFully(input: InputStream, target: ByteArray) {
        var offset = 0
        while (offset < target.size) {
            val count = input.read(target, offset, target.size - offset)
            if (count < 0) throw IllegalArgumentException("Archivo cifrado truncado")
            offset += count
        }
    }

    fun toHex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }

    fun fromHex(value: String): ByteArray {
        require(value.length == 64 && value.all { it in "0123456789abcdefABCDEF" }) {
            "La clave de recuperación debe contener 64 caracteres hexadecimales"
        }
        return ByteArray(value.length / 2) { index ->
            value.substring(index * 2, index * 2 + 2).toInt(16).toByte()
        }
    }
}
