package com.y37x.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Local master-key envelope. The PIN/pattern is never persisted. */
class KeyManager(
    context: Context,
    preferencesName: String = "y37x_security",
    private val alias: String = "y37x_device_hmac_v1"
) {
    private val prefs = context.getSharedPreferences(preferencesName, Context.MODE_PRIVATE)
    private val iterations = 310_000

    fun isConfigured(): Boolean = prefs.contains(KEY_ENVELOPE)
    fun method(): String = runCatching {
        JSONObject(prefs.getString(KEY_ENVELOPE, "") ?: "").optString("method", "PIN")
    }.getOrDefault("PIN")

    fun saveLocalEnvelope(masterKey: ByteArray, credential: String, method: String) {
        require(credential.isNotBlank())
        val salt = CryptoEngine.randomBytes(16)
        val wrappingKey = deriveLocalKey(credential, salt)
        val encryptedMaster = try {
            CryptoEngine.encryptBytes(masterKey, wrappingKey, LOCAL_AAD)
        } finally {
            wrappingKey.fill(0)
        }
        val json = JSONObject()
            .put("version", 1)
            .put("method", method)
            .put("iterations", iterations)
            .put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .put("master", Base64.encodeToString(encryptedMaster, Base64.NO_WRAP))
        check(prefs.edit().putString(KEY_ENVELOPE, json.toString()).putInt(FAILED_ATTEMPTS, 0).putLong(BLOCKED_UNTIL, 0L).commit()) { "No se pudo guardar la credencial" }
    }

    fun unlock(credential: String): ByteArray {
        val now = System.currentTimeMillis()
        val blockedUntil = prefs.getLong(BLOCKED_UNTIL, 0L)
        if (now < blockedUntil) throw IllegalStateException("Demasiados intentos. Inténtalo más tarde.")
        val raw = prefs.getString(KEY_ENVELOPE, null) ?: throw IllegalStateException("La bóveda aún no está configurada")
        val json = JSONObject(raw)
        require(json.optInt("version", 0) == 1) { "Versión de credenciales no compatible" }
        val salt = Base64.decode(json.getString("salt"), Base64.NO_WRAP)
        val encryptedMaster = Base64.decode(json.getString("master"), Base64.NO_WRAP)
        val wrappingKey = deriveLocalKey(credential, salt, json.optInt("iterations", iterations))
        return try {
            CryptoEngine.decryptBytes(encryptedMaster, wrappingKey, LOCAL_AAD).also {
                prefs.edit().putInt(FAILED_ATTEMPTS, 0).putLong(BLOCKED_UNTIL, 0L).apply()
            }
        } catch (error: Exception) {
            val attempts = prefs.getInt(FAILED_ATTEMPTS, 0) + 1
            val delaySeconds = if (attempts < 5) 0L else (30L * (1L shl (attempts - 5).coerceAtMost(7))).coerceAtMost(3600L)
            prefs.edit().putInt(FAILED_ATTEMPTS, attempts).putLong(BLOCKED_UNTIL, now + delaySeconds * 1000L).apply()
            throw error
        } finally {
            wrappingKey.fill(0)
        }
    }

    fun clearLocalEnvelope() {
        prefs.edit().remove(KEY_ENVELOPE).commit()
    }

    fun snapshotLocalEnvelope(): String? = prefs.getString(KEY_ENVELOPE, null)

    fun restoreLocalEnvelope(snapshot: String?) {
        val editor = prefs.edit()
        if (snapshot == null) editor.remove(KEY_ENVELOPE) else editor.putString(KEY_ENVELOPE, snapshot)
        editor.commit()
    }

    private fun deriveLocalKey(credential: String, salt: ByteArray, rounds: Int = iterations): ByteArray {
        val password = credential.toCharArray()
        val spec = PBEKeySpec(password, salt, rounds, 256)
        val stretched = try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
            password.fill('\u0000')
        }
        return try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(getOrCreateDeviceKey())
            mac.doFinal(stretched)
        } finally {
            stretched.fill(0)
        }
    }

    private fun getOrCreateDeviceKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
            ).setDigests(KeyProperties.DIGEST_SHA256).build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val KEY_ENVELOPE = "local_master_envelope"
        private const val FAILED_ATTEMPTS = "failed_attempts"
        private const val BLOCKED_UNTIL = "blocked_until"
        private val LOCAL_AAD = "y37x-local-master-v1".toByteArray(Charsets.UTF_8)
    }
}
