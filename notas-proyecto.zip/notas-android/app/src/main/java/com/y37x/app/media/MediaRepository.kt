package com.y37x.app.media

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

 data class MediaEntry(
    val id: Long,
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val size: Long,
    val dateAdded: Long,
    val isVideo: Boolean,
    val durationMs: Long = 0L
)

object MediaRepository {
    fun loadImages(context: Context): List<MediaEntry> = query(context, false)
    fun loadVideos(context: Context): List<MediaEntry> = query(context, true)

    private fun query(context: Context, videos: Boolean): List<MediaEntry> {
        val collection = if (videos) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            if (videos) MediaStore.Video.Media.DURATION else MediaStore.MediaColumns.DATE_MODIFIED
        )
        val selection: String? = if (videos) null else "${MediaStore.MediaColumns.MIME_TYPE} IN (?, ?, ?)"
        val args: Array<String>? = if (videos) null else arrayOf("image/jpeg", "image/png", "image/jpg")
        val result = mutableListOf<MediaEntry>()
        context.contentResolver.query(
            collection,
            projection,
            selection,
            args,
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val durationCol = cursor.getColumnIndexOrThrow(if (videos) MediaStore.Video.Media.DURATION else MediaStore.MediaColumns.DATE_MODIFIED)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                result += MediaEntry(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id),
                    name = cursor.getString(nameCol) ?: "archivo",
                    mimeType = cursor.getString(mimeCol) ?: if (videos) "video/*" else "image/*",
                    size = cursor.getLong(sizeCol),
                    dateAdded = cursor.getLong(dateCol),
                    isVideo = videos,
                    durationMs = if (videos) cursor.getLong(durationCol) else 0L
                )
            }
        }
        return result
    }
}
