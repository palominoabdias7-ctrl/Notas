package com.y37x.app.ui

import android.app.Activity
import android.net.Uri
import android.graphics.BitmapFactory
import android.view.WindowManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.y37x.app.data.VaultItemMetadata
import com.y37x.app.vault.VaultRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

@Composable
fun SetupSecurityScreen(vault: VaultRepository, onFinished: () -> Unit) {
    SecureWindow()
    var method by remember { mutableStateOf("PIN") }
    var pin by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var firstPattern by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf("") }
    var recoveryKey by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (recoveryKey != null) {
        RecoveryKeyScreen(recoveryKey = recoveryKey!!, onFinished = onFinished)
        return
    }

    Column(Modifier.fillMaxSize().background(Y37xBackground).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        ScreenHeader("Configura PRIVACIDAD", "Crea la credencial para tu bóveda")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            if (method == "PIN") Button(onClick = { method = "PIN"; error = "" }, modifier = Modifier.weight(1f)) { Text("PIN") }
            else OutlinedButton(onClick = { method = "PIN"; error = "" }, modifier = Modifier.weight(1f)) { Text("PIN") }
            if (method == "PATRÓN") Button(onClick = { method = "PATRÓN"; error = "" }, modifier = Modifier.weight(1f)) { Text("Patrón") }
            else OutlinedButton(onClick = { method = "PATRÓN"; error = "" }, modifier = Modifier.weight(1f)) { Text("Patrón") }
        }
        Spacer(Modifier.height(22.dp))
        if (method == "PIN") {
            Text("Elige un PIN de al menos 6 dígitos.", color = Y37xMuted)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = { if (it.length <= 12 && it.all(Char::isDigit)) pin = it },
                label = { Text("Nuevo PIN") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = pinConfirm,
                onValueChange = { if (it.length <= 12 && it.all(Char::isDigit)) pinConfirm = it },
                label = { Text("Repetir PIN") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true
            )
            Spacer(Modifier.height(18.dp))
            PrimaryButton("Crear bóveda", onClick = {
                busy = true
                scope.launch {
                    runCatching { vault.initialize(pin, method) }
                        .onSuccess { recoveryKey = it; pin = ""; pinConfirm = "" }
                        .onFailure { error = it.message ?: "No se pudo crear la bóveda" }
                    busy = false
                }
            }, enabled = !busy && pin.length >= 6 && pin == pinConfirm)
        } else {
            Text(if (firstPattern == null) "Dibuja un patrón de al menos 4 puntos." else "Repite el patrón para confirmarlo.", color = Y37xMuted)
            Spacer(Modifier.height(8.dp))
            PatternLock(onPattern = { pattern ->
                if (busy) return@PatternLock
                if (pattern.split('-').distinct().size < 4) {
                    error = "Usa al menos 4 puntos"
                } else if (firstPattern == null) {
                    firstPattern = pattern
                    error = ""
                } else if (firstPattern == pattern) {
                    busy = true
                    scope.launch {
                        runCatching { vault.initialize(pattern, method) }
                            .onSuccess { recoveryKey = it; firstPattern = null }
                            .onFailure { error = it.message ?: "No se pudo crear la bóveda" }
                        busy = false
                    }
                } else {
                    firstPattern = null
                    error = "Los patrones no coinciden. Inténtalo otra vez."
                }
            })
            if (firstPattern != null) TextButton(onClick = { firstPattern = null }) { Text("Reiniciar patrón") }
        }
        if (busy) CircularProgressIndicator(color = Y37xGreen, modifier = Modifier.padding(12.dp))
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(16.dp))
        Text("La credencial no se guarda en texto plano. La clave maestra se protege con Android Keystore.", color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun RecoveryKeyScreen(recoveryKey: String, onFinished: () -> Unit) {
    val activity = LocalContext.current.findActivity()
    var saved by remember { mutableStateOf(false) }
    DisposableEffect(activity) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    Column(Modifier.fillMaxSize().background(Y37xBackground).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Guarda tu clave de recuperación", style = MaterialTheme.typography.headlineMedium, color = Y37xText, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Esta clave es independiente del PIN o patrón. Se necesita para recuperar la bóveda después de desinstalar o cambiar de teléfono.", color = Y37xMuted)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Y37xCard)) {
            SelectionContainer {
                Text(recoveryKey, modifier = Modifier.padding(16.dp), color = Y37xGreen, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Anótala o guárdala en un gestor seguro. Evita compartirla por mensajes.", color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = saved, onCheckedChange = { saved = it })
            Text("He guardado esta clave en un lugar seguro", color = Y37xText)
        }
        PrimaryButton("Continuar", onClick = onFinished, enabled = saved)
        Spacer(Modifier.height(10.dp))
        Text("y37x no conserva una copia legible de esta clave. Si la pierdes y no tienes otra copia válida, los archivos cifrados serán irrecuperables.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun UnlockScreen(vault: VaultRepository, onUnlocked: () -> Unit) {
    SecureWindow()
    val method = vault.authMethod()
    var credential by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(Y37xBackground).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(32.dp))
        BrandMark(size = 66)
        Spacer(Modifier.height(18.dp))
        Text("PRIVACIDAD", style = MaterialTheme.typography.headlineMedium, color = Y37xText, fontWeight = FontWeight.Bold)
        Text("Desbloquea tu bóveda", color = Y37xMuted)
        Spacer(Modifier.height(24.dp))
        if (method == "PATRÓN") {
            Text("Dibuja tu patrón", color = Y37xMuted)
            PatternLock(onPattern = { entered ->
                if (!busy) {
                    busy = true
                    scope.launch {
                        val ok = vault.unlock(entered)
                        if (ok) onUnlocked() else error = "Credencial incorrecta"
                        busy = false
                    }
                }
            })
        } else {
            OutlinedTextField(
                value = credential,
                onValueChange = { if (it.length <= 12 && it.all(Char::isDigit)) credential = it },
                label = { Text("PIN") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true
            )
            Spacer(Modifier.height(14.dp))
            PrimaryButton("Desbloquear", onClick = {
                busy = true
                scope.launch {
                    val ok = vault.unlock(credential)
                    if (ok) onUnlocked() else error = "Credencial incorrecta"
                    credential = ""
                    busy = false
                }
            }, enabled = !busy && credential.isNotBlank())
        }
        if (busy) CircularProgressIndicator(color = Y37xGreen, modifier = Modifier.padding(12.dp))
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
fun VaultScreen(vault: VaultRepository, onOpen: (String) -> Unit, onLock: () -> Unit, onBackups: () -> Unit) {
    val context = LocalContext.current
    val activity = context.findActivity()
    var items by remember { mutableStateOf<List<Pair<com.y37x.app.data.VaultItemEntity, VaultItemMetadata>>>(emptyList()) }
    var deleting by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    DisposableEffect(activity) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    suspend fun refreshItems() {
        runCatching { vault.listItems() }.onSuccess { items = it }.onFailure { error = it.message ?: "No se pudo leer la bóveda" }
    }
    LaunchedEffect(Unit) { refreshItems() }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) scope.launch { refreshItems() }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(Modifier.fillMaxSize().background(Y37xBackground)) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PRIVACIDAD", style = MaterialTheme.typography.headlineMedium, color = Y37xText, fontWeight = FontWeight.Bold)
                    Text("${items.size} elementos cifrados", color = Y37xMuted)
                }
                TextButton(onClick = onBackups) { Text("Respaldar", color = Y37xGreen) }
                TextButton(onClick = onLock) { Text("Bloquear", color = Y37xGreen) }
            }
            Text("Los archivos no aparecen en la galería pública.", color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(18.dp))
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.Lock, null, tint = Y37xGreen, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Tu bóveda está vacía", color = Y37xText, fontWeight = FontWeight.SemiBold)
                    Text("Selecciona archivos desde Fotos o Videos.", color = Y37xMuted)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
                items(items, key = { it.first.id }) { (entity, metadata) ->
                    Card(colors = CardDefaults.cardColors(containerColor = Y37xPanel), shape = RoundedCornerShape(16.dp)) {
                        Row(
                            Modifier.fillMaxWidth().clickable { onOpen(entity.id) }.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(if (metadata.isVideo) Icons.Outlined.PlayCircle else Icons.Outlined.Image, null, tint = Y37xGreen, modifier = Modifier.size(30.dp))
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(metadata.originalName, color = Y37xText, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text("${formatBytes(metadata.size)} · ${metadata.mimeType}", color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { deleting = entity.id }) { Text("Eliminar", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
    }
    deleting?.let { id ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Eliminar de PRIVACIDAD") },
            text = { Text("Se eliminará el archivo cifrado de este dispositivo. Las copias de seguridad anteriores no se modifican.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch { vault.deleteItem(id); items = vault.listItems() }
                }) { Text("Eliminar", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun PrivateViewerScreen(vault: VaultRepository, id: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = context.findActivity()
    var file by remember { mutableStateOf<File?>(null) }
    var imageBitmap by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var metadata by remember { mutableStateOf<VaultItemMetadata?>(null) }
    var error by remember { mutableStateOf("") }
    DisposableEffect(activity) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    LaunchedEffect(id) {
        runCatching {
            val item = vault.itemById(id) ?: throw IllegalStateException("Archivo no encontrado")
            metadata = item.second
            val decrypted = vault.decryptPreview(id)
            file = decrypted
            if (!item.second.isVideo) {
                imageBitmap = withContext(Dispatchers.IO) { decodePrivateImage(decrypted)?.asImageBitmap() }
            }
        }.onFailure { error = it.message ?: "No se pudo abrir el archivo privado" }
    }
    DisposableEffect(file) { onDispose { file?.delete() } }
    Column(Modifier.fillMaxSize().background(Y37xBackground)) {
        ScreenHeader(metadata?.originalName ?: "Archivo privado", "Vista protegida · capturas bloqueadas", onBack)
        when {
            error.isNotBlank() -> Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(20.dp))
            file == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Y37xGreen) }
            metadata?.isVideo == true -> VideoPlayer(Uri.fromFile(file!!), Modifier.fillMaxWidth().weight(1f))
            else -> imageBitmap?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.fillMaxSize().padding(8.dp), contentScale = ContentScale.Fit) }
        }
    }
}

@Composable
fun ChangeSecurityScreen(vault: VaultRepository, onDone: () -> Unit, onBack: () -> Unit) {
    SecureWindow()
    val oldMethod = vault.authMethod()
    var oldCredential by remember { mutableStateOf("") }
    var newMethod by remember { mutableStateOf(oldMethod) }
    var newCredential by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var firstPattern by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().background(Y37xBackground).padding(22.dp)) {
        ScreenHeader("Cambiar seguridad", "Confirma la credencial actual y define la nueva", onBack)
        if (oldMethod == "PATRÓN") {
            Text("Patrón actual", color = Y37xMuted)
            PatternLock(onPattern = { oldCredential = it })
        } else {
            OutlinedTextField(oldCredential, { oldCredential = it }, label = { Text("PIN actual") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), visualTransformation = PasswordVisualTransformation(), singleLine = true)
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (newMethod == "PIN") Button(onClick = { newMethod = "PIN" }) { Text("PIN") } else OutlinedButton(onClick = { newMethod = "PIN" }) { Text("PIN") }
            if (newMethod == "PATRÓN") Button(onClick = { newMethod = "PATRÓN" }) { Text("Patrón") } else OutlinedButton(onClick = { newMethod = "PATRÓN" }) { Text("Patrón") }
        }
        if (newMethod == "PIN") {
            OutlinedTextField(newCredential, { if (it.length <= 12 && it.all(Char::isDigit)) newCredential = it }, label = { Text("Nuevo PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(confirm, { if (it.length <= 12 && it.all(Char::isDigit)) confirm = it }, label = { Text("Repetir PIN") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), visualTransformation = PasswordVisualTransformation(), singleLine = true)
        } else {
            Text("Dibuja el nuevo patrón dos veces", color = Y37xMuted)
            PatternLock(onPattern = { pattern ->
                if (firstPattern == null) firstPattern = pattern
                else if (firstPattern == pattern) { newCredential = pattern; confirm = pattern }
                else { firstPattern = null; error = "Los patrones no coinciden" }
            })
        }
        Spacer(Modifier.height(16.dp))
        PrimaryButton("Guardar cambios", onClick = {
            busy = true
            scope.launch {
                runCatching { vault.changeCredential(oldCredential, newCredential, newMethod) }
                    .onSuccess { onDone() }
                    .onFailure { error = "Credencial actual incorrecta o no se pudo actualizar" }
                busy = false
                }
            }, enabled = !busy && oldCredential.isNotBlank() && newCredential.length >= (if (newMethod == "PIN") 6 else 4) && (newMethod == "PIN" || newCredential.split('-').distinct().size >= 4) && newCredential == confirm)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp))
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024L -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
    bytes >= 1024L -> String.format("%.0f KB", bytes / 1024.0)
    else -> "$bytes B"
}

private fun decodePrivateImage(file: File): android.graphics.Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    val maxDimension = 4096
    var sample = 1
    while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) sample *= 2
    val options = BitmapFactory.Options().apply { inSampleSize = sample.coerceAtLeast(1) }
    return BitmapFactory.decodeFile(file.absolutePath, options)
}
