package com.y37x.app.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Notes
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.y37x.app.security.CryptoEngine
import com.y37x.app.security.KeyManager
import com.y37x.app.vault.VaultRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Separate entrance credential: never replaces or resets the vault encryption key. */
class NotesEntrance(context: Context) {
    private val keys = KeyManager(context, "y37x_notes_entrance", "y37x_notes_entrance_hmac_v1")
    fun isConfigured() = keys.isConfigured()
    fun verify(pin: String): Boolean = runCatching {
        keys.unlock(pin).fill(0)
        true
    }.getOrDefault(false)

    fun save(pin: String, previous: String) {
        require(pin.length in 6..12 && pin.all { it in '0'..'9' })
        check(!isConfigured() || verify(previous)) { "Contraseña actual incorrecta o temporalmente bloqueada" }
        val secret = CryptoEngine.randomBytes(32)
        try { keys.saveLocalEnvelope(secret, pin, "PIN") } finally { secret.fill(0) }
    }
}

data class SavedNote(val id: String, val title: String, val body: String)

class NotesStore(context: Context) {
    private val prefs = context.getSharedPreferences("y37x_notes", Context.MODE_PRIVATE)
    fun load(): List<SavedNote> {
        val array = JSONArray(prefs.getString("notes", "[]") ?: "[]")
        return (0 until array.length()).map { index ->
            val note = array.getJSONObject(index)
            SavedNote(note.getString("id"), note.getString("title"), note.getString("body"))
        }
    }
    fun save(notes: List<SavedNote>) {
        val array = JSONArray()
        notes.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body)) }
        check(prefs.edit().putString("notes", array.toString()).commit()) { "No se pudo guardar la nota" }
    }
}

@Composable
fun Y37xApp(vault: VaultRepository) {
    val context = LocalContext.current
    val entrance = remember { NotesEntrance(context) }
    var privateMenu by remember { mutableStateOf(false) }
    if (privateMenu) {
        BackHandler { vault.lock(); privateMenu = false }
        SecureWindow()
        PrivateGalleryApp(vault)
    } else {
        MaterialTheme(colorScheme = darkColorScheme(
            primary = Color(0xFFC39977), onPrimary = Color(0xFF24170E),
            primaryContainer = Color(0xFF59412E), onPrimaryContainer = Color(0xFFF6DFCC),
            secondary = Color(0xFFBFA68F), background = Color(0xFF100D0B),
            onBackground = Color(0xFFF5EDE7), surface = Color(0xFF211A15),
            onSurface = Color(0xFFF5EDE7), surfaceVariant = Color(0xFF33291F),
            onSurfaceVariant = Color(0xFFB9AA9E), outline = Color(0xFF796554)
        )) {
            NotesScreen(entrance) { privateMenu = true }
        }
    }
}

@Composable
private fun NotesScreen(entrance: NotesEntrance, onOpenPrivate: () -> Unit) {
    val context = LocalContext.current
    val store = remember { NotesStore(context) }
    var notes by remember { mutableStateOf(emptyList<SavedNote>()) }
    var loaded by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf("list") }
    var noteId by remember { mutableStateOf<String?>(null) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    var optionsOpen by remember { mutableStateOf(false) }

    LaunchedEffect(store) {
        runCatching { withContext(Dispatchers.IO) { store.load() } }
            .onSuccess { notes = it; loaded = true }
            .onFailure { error = "No se pudieron leer las notas. Reinicia la aplicación." }
    }

    fun submit(text: String, saveNote: Boolean) {
        if (busy || !loaded) return
        busy = true
        error = ""
        scope.launch {
            try {
                val open = withContext(Dispatchers.IO) {
                    text.length in 6..12 && text.all { it in '0'..'9' } &&
                        entrance.isConfigured() && entrance.verify(text)
                }
                if (open) {
                    // The code never enters the note store or a saved-instance-state bundle.
                    body = ""
                    title = ""
                    noteId = null
                    onOpenPrivate()
                } else if (saveNote) {
                    val note = SavedNote(noteId ?: UUID.randomUUID().toString(), title, text)
                    val updated = listOf(note) + notes.filterNot { it.id == note.id }
                    withContext(Dispatchers.IO) { store.save(updated) }
                    notes = updated
                    body = ""
                    title = ""
                    noteId = null
                    page = "list"
                } else {
                    body = text + "\n"
                }
            } catch (_: Exception) {
                error = "No se pudo completar la operación. Inténtalo otra vez."
            } finally { busy = false }
        }
    }

    BackHandler(enabled = page != "list" && !busy) {
        page = "list"; body = ""; title = ""; error = ""
    }
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = page == "list",
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.fillMaxHeight().widthIn(max = 310.dp),
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(start = 24.dp, top = 12.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("Notas", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    Box {
                        // Small visible dot with a full accessible touch target.
                        IconButton(onClick = { optionsOpen = true }, modifier = Modifier.semantics { contentDescription = "Más opciones" }) {
                            Box(Modifier.size(5.dp).background(MaterialTheme.colorScheme.primary, CircleShape))
                        }
                        DropdownMenu(expanded = optionsOpen, onDismissRequest = { optionsOpen = false }) {
                            DropdownMenuItem(text = { Text("Ajustes adicionales") }, onClick = {
                                optionsOpen = false
                                scope.launch { drawerState.close(); page = "settings" }
                            })
                            DropdownMenuItem(text = { Text("Cerrar menú") }, onClick = {
                                optionsOpen = false
                                scope.launch { drawerState.close() }
                            })
                        }
                    }
                }
                Spacer(Modifier.height(32.dp))
                NavigationDrawerItem(label = { Text("Todas las notas") }, selected = page == "list",
                    icon = { Icon(Icons.Outlined.Notes, contentDescription = null) },
                    modifier = Modifier.padding(horizontal = 12.dp),
                    onClick = { scope.launch { drawerState.close(); page = "list" } })
                NavigationDrawerItem(label = { Text("Nueva nota") }, selected = false,
                    icon = { Icon(Icons.Outlined.EditNote, contentDescription = null) },
                    modifier = Modifier.padding(horizontal = 12.dp),
                    onClick = {
                        scope.launch { drawerState.close(); noteId = null; title = ""; body = ""; page = "edit" }
                    })
            }
        }
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            floatingActionButton = {
                if (page == "list") FloatingActionButton(
                    onClick = { if (loaded) { noteId = null; title = ""; body = ""; page = "edit" } },
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.primary,
                    shape = CircleShape
                ) { Icon(Icons.Outlined.EditNote, contentDescription = "Añadir nota") }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).imePadding().padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (page) {
                    "settings" -> EntranceSettings(entrance, onBack = { page = "list" })
                    "edit" -> {
                        Spacer(Modifier.height(12.dp))
                        Text("Nota", style = MaterialTheme.typography.headlineMedium)
                        OutlinedTextField(title, { title = it }, label = { Text("Título") }, singleLine = true,
                            enabled = !busy, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = body, onValueChange = { next ->
                            val candidate = next.removeSuffix("\n")
                            if (next == body + "\n" && candidate.length in 6..12 && candidate.all { it in '0'..'9' }) {
                                submit(candidate, false)
                            } else { body = next }
                        }, label = { Text("Escribe aquí") }, enabled = !busy && loaded,
                            modifier = Modifier.fillMaxWidth().weight(1f))
                        Row(Modifier.padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(onClick = { submit(body, true) }, enabled = !busy && loaded) { Text("Guardar") }
                            OutlinedButton(onClick = { page = "list"; body = ""; title = "" }, enabled = !busy) { Text("Volver") }
                        }
                    }
                    else -> {
                        Spacer(Modifier.height(52.dp))
                        Text("Todas las notas", fontSize = 34.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(start = 24.dp, bottom = 36.dp))
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Outlined.Menu, contentDescription = "Abrir menú", tint = MaterialTheme.colorScheme.primary)
                        }
                        if (loaded && notes.isEmpty()) {
                            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("No hay notas", style = MaterialTheme.typography.titleLarge)
                                    Text("Pulsa el botón Añadir para crear una nota.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        } else {
                            LazyColumn(modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(bottom = 96.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(notes, key = { it.id }) { note ->
                                    Card(Modifier.fillMaxWidth().clickable {
                                        noteId = note.id; title = note.title; body = note.body; page = "edit"
                                    }, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(note.title.ifBlank { "Sin título" }, style = MaterialTheme.typography.titleMedium)
                                            Text(note.body, maxLines = 3, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun EntranceSettings(entrance: NotesEntrance, onBack: () -> Unit) {
    SecureWindow()
    val scope = rememberCoroutineScope()
    var configured by remember { mutableStateOf(entrance.isConfigured()) }
    var current by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ajustes adicionales", style = MaterialTheme.typography.headlineMedium)
        Text(if (configured) "Cambiar contraseña" else "Crear contraseña", style = MaterialTheme.typography.titleLarge)
        Text("Usa entre 6 y 12 dígitos y guarda la contraseña en un lugar seguro.")
        if (configured) PinInput("Contraseña actual", current, !busy) { current = it }
        PinInput("Nueva contraseña", pin, !busy) { pin = it }
        PinInput("Confirmar contraseña", confirm, !busy) { confirm = it }
        Button(enabled = !busy && pin.length in 6..12 && pin == confirm && (!configured || current.isNotEmpty()), onClick = {
            busy = true
            scope.launch {
                try {
                    withContext(Dispatchers.IO) { entrance.save(pin, current) }
                    current = ""; pin = ""; confirm = ""; configured = true
                    message = "Contraseña guardada"
                } catch (_: Exception) {
                    message = "No se pudo guardar. Comprueba la contraseña actual; si hubo varios intentos, espera e inténtalo de nuevo."
                } finally { busy = false }
            }
        }) { Text("Confirmar") }
        OutlinedButton(onClick = onBack, enabled = !busy) { Text("Volver") }
        if (message.isNotEmpty()) Text(message)
    }
}

@Composable
private fun PinInput(label: String, value: String, enabled: Boolean, onChange: (String) -> Unit) {
    OutlinedTextField(value, { if (it.length <= 12 && it.all { char -> char in '0'..'9' }) onChange(it) },
        label = { Text(label) }, singleLine = true, enabled = enabled,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
}
