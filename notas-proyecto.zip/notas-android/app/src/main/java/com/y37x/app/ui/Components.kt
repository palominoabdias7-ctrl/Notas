package com.y37x.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.WindowManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.hypot

val Y37xBackground = Color(0xFF090B0A)
val Y37xPanel = Color(0xFF111613)
val Y37xCard = Color(0xFF202522)
val Y37xGreen = Color(0xFF00C875)
val Y37xDarkGreen = Color(0xFF123D2B)
val Y37xText = Color(0xFFF2F5F3)
val Y37xMuted = Color(0xFF9BA69F)

@Composable
fun BrandMark(modifier: Modifier = Modifier, size: Int = 34) {
    Box(
        modifier = modifier
            .size(size.dp)
            .background(Y37xDarkGreen, RoundedCornerShape(11.dp))
            .border(1.dp, Y37xGreen.copy(alpha = 0.7f), RoundedCornerShape(11.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text("y37x", color = Y37xText, fontSize = (size * 0.27f).sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp)) {
        if (onBack != null) {
            OutlinedButton(onClick = onBack, colors = ButtonDefaults.outlinedButtonColors(contentColor = Y37xGreen)) {
                Text("←  Volver")
            }
            Spacer(Modifier.height(12.dp))
        }
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Y37xText)
        if (subtitle != null) {
            Spacer(Modifier.height(4.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Y37xMuted)
        }
    }
}

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().height(52.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Y37xGreen, contentColor = Color(0xFF001F12), disabledContainerColor = Y37xDarkGreen)
    ) {
        Text(text, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PatternLock(onPattern: (String) -> Unit, modifier: Modifier = Modifier) {
    val selected = remember { mutableStateListOf<Int>() }
    val callback by rememberUpdatedState(onPattern)
    Canvas(
        modifier = modifier
            .size(270.dp)
            .pointerInput(Unit) {
                fun appendNode(index: Int) {
                    if (index in selected) return
                    val previous = selected.lastOrNull()
                    if (previous != null) {
                        val x1 = previous % 3
                        val y1 = previous / 3
                        val x2 = index % 3
                        val y2 = index / 3
                        val dx = x2 - x1
                        val dy = y2 - y1
                        val middle = when {
                            abs(dx) == 2 && dy == 0 -> y1 * 3 + (x1 + x2) / 2
                            abs(dy) == 2 && dx == 0 -> ((y1 + y2) / 2) * 3 + x1
                            abs(dx) == 2 && abs(dy) == 2 -> ((y1 + y2) / 2) * 3 + (x1 + x2) / 2
                            else -> null
                        }
                        if (middle != null && middle !in selected) selected.add(middle)
                    }
                    selected.add(index)
                }
                fun hitNode(position: Offset): Int? {
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val xs = listOf(w * 0.18f, w * 0.5f, w * 0.82f)
                    val ys = listOf(h * 0.18f, h * 0.5f, h * 0.82f)
                    var best: Int? = null
                    var bestDistance = minOf(w, h) * 0.14f
                    for (row in 0..2) for (col in 0..2) {
                        val distance = hypot((position.x - xs[col]).toDouble(), (position.y - ys[row]).toDouble()).toFloat()
                        if (distance < bestDistance) {
                            bestDistance = distance
                            best = row * 3 + col
                        }
                    }
                    return best
                }
                detectDragGestures(
                    onDragStart = { point -> hitNode(point)?.let(::appendNode) },
                    onDrag = { change, _ ->
                        hitNode(change.position)?.let(::appendNode)
                        change.consume()
                    },
                    onDragEnd = {
                        if (selected.isNotEmpty()) callback(selected.joinToString("-"))
                        selected.clear()
                    },
                    onDragCancel = { selected.clear() }
                )
            }
    ) {
        val xs = listOf(size.width * 0.18f, size.width * 0.5f, size.width * 0.82f)
        val ys = listOf(size.height * 0.18f, size.height * 0.5f, size.height * 0.82f)
        if (selected.size > 1) {
            val path = Path().apply {
                selected.forEachIndexed { index, node ->
                    val point = Offset(xs[node % 3], ys[node / 3])
                    if (index == 0) moveTo(point.x, point.y) else lineTo(point.x, point.y)
                }
            }
            drawPath(path, Y37xGreen, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 7.dp.toPx()))
        }
        for (row in 0..2) for (col in 0..2) {
            val index = row * 3 + col
            val point = Offset(xs[col], ys[row])
            drawCircle(if (index in selected) Y37xGreen else Y37xMuted, radius = 17.dp.toPx(), center = point)
            drawCircle(Y37xPanel, radius = 7.dp.toPx(), center = point)
        }
    }
}

fun Context.findActivity(): Activity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return current as? Activity
}

@Composable
fun SecureWindow() {
    val activity = androidx.compose.ui.platform.LocalContext.current.findActivity()
    DisposableEffect(activity) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
}
