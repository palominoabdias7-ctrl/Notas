package com.y37x.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Y37xColors = darkColorScheme(
    primary = Color(0xFF00C875),
    onPrimary = Color(0xFF001F12),
    primaryContainer = Color(0xFF123D2B),
    onPrimaryContainer = Color(0xFFB7F5D5),
    secondary = Color(0xFF8FD9B6),
    background = Color(0xFF090B0A),
    onBackground = Color(0xFFF2F5F3),
    surface = Color(0xFF111613),
    onSurface = Color(0xFFF2F5F3),
    surfaceVariant = Color(0xFF202522),
    onSurfaceVariant = Color(0xFFB7C0BA),
    outline = Color(0xFF46524B),
    error = Color(0xFFFF6B6B)
)

@Composable
fun Y37xTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = Y37xColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
