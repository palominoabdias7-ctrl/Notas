package com.y37x.app.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [VaultItemEntity::class], version = 1, exportSchema = true)
abstract class VaultDatabase : RoomDatabase() {
    abstract fun vaultDao(): VaultDao
}
