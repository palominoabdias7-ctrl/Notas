package com.y37x.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vault_items")
data class VaultItemEntity(
    @PrimaryKey val id: String,
    val fileName: String,
    /** AES-GCM encrypted JSON. No original filename, MIME type or size is stored in plaintext. */
    val encryptedMetadata: String,
    val addedAt: Long
)

data class VaultItemMetadata(
    val originalName: String,
    val mimeType: String,
    val size: Long,
    val isVideo: Boolean,
    val dateAdded: Long
)
