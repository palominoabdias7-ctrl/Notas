package com.y37x.app.backup

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.y37x.app.Y37xApplication
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class VaultBackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val prefs = applicationContext.getSharedPreferences(BackupManager.PREFS, Context.MODE_PRIVATE)
        val treeText = prefs.getString(BackupManager.TREE_URI, null) ?: return@withContext Result.failure()
        val tree = DocumentFile.fromTreeUri(applicationContext, Uri.parse(treeText))
            ?: return@withContext Result.failure()
        if (!tree.isDirectory || !tree.canWrite()) return@withContext Result.failure()

        val app = applicationContext as Y37xApplication
        val temp = File(applicationContext.cacheDir, "y37x-auto-backup-${id}.zip")
        var staged: DocumentFile? = null
        try {
            BackupManager(applicationContext, app.database.vaultDao(), app.vault).createArchive(temp)
            val publishedName = "y37x-backup-${System.currentTimeMillis()}.zip"
            val publishedFile = tree.createFile("application/zip", publishedName)
                ?: return@withContext Result.retry()
            staged = publishedFile
            val output = applicationContext.contentResolver.openOutputStream(publishedFile.uri, "w")
                ?: throw IllegalStateException("El proveedor no pudo abrir el archivo de respaldo")
            output.use { stream -> temp.inputStream().use { input -> input.copyTo(stream) } }
            val localDigest = temp.inputStream().use { sha256(it) }
            val remoteDigest = applicationContext.contentResolver.openInputStream(publishedFile.uri)?.use { sha256(it) }
                ?: throw IllegalStateException("No se pudo verificar la copia guardada")
            require(localDigest.contentEquals(remoteDigest)) { "La copia guardada no coincide con el archivo local" }

            // Publish only after the new archive has been fully written and read back successfully.
            tree.listFiles()
                .filter { it.name?.startsWith("y37x-backup-") == true && it.name?.endsWith(".zip") == true && it.uri != publishedFile.uri }
                .forEach { it.delete() }
            prefs.edit().putLong(BackupManager.LAST_BACKUP, System.currentTimeMillis()).apply()
            Result.success()
        } catch (_: Exception) {
            staged?.delete()
            Result.retry()
        } finally {
            temp.delete()
        }
    }

    private fun sha256(input: InputStream): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (count > 0) digest.update(buffer, 0, count)
        }
        return digest.digest()
    }

    companion object {
        fun schedule(context: Context) {
            val request = androidx.work.PeriodicWorkRequestBuilder<VaultBackupWorker>(24, TimeUnit.HOURS)
                .setConstraints(
                    androidx.work.Constraints.Builder()
                        .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED)
                        .build()
                )
                .build()
            androidx.work.WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "y37x-encrypted-drive-backup",
                androidx.work.ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }

        fun runNow(context: Context) {
            val request = androidx.work.OneTimeWorkRequestBuilder<VaultBackupWorker>().build()
            androidx.work.WorkManager.getInstance(context).enqueueUniqueWork(
                "y37x-backup-manual",
                androidx.work.ExistingWorkPolicy.REPLACE,
                request
            )
        }

        fun cancel(context: Context) {
            androidx.work.WorkManager.getInstance(context).cancelUniqueWork("y37x-encrypted-drive-backup")
        }
    }
}
