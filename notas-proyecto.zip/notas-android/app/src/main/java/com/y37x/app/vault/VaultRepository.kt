package com.y37x.app.vault

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.y37x.app.data.VaultDao
import com.y37x.app.data.VaultItemEntity
import com.y37x.app.data.VaultItemMetadata
import com.y37x.app.security.CryptoEngine
import com.y37x.app.security.KeyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

class VaultRepository(
    private val context: Context,
    private val dao: VaultDao,
    private val keyManager: KeyManager
) {
    private val root = File(context.noBackupFilesDir, "y37x")
    val vaultDirectory: File get() = File(root, "vault")
    val recoveryEnvelopeFile: File get() = File(root, "recovery-envelope.bin")

    @Volatile private var masterKey: ByteArray? = null

    init {
        vaultDirectory.mkdirs()
        // Remove decrypted previews left behind by an interrupted process.
        context.cacheDir.listFiles()?.filter { it.name.startsWith("y37x-preview-") || it.name.startsWith("y37x-verify-") }?.forEach { it.delete() }
    }

    fun isConfigured(): Boolean = keyManager.isConfigured()
    fun authMethod(): String = keyManager.method()
    fun isUnlocked(): Boolean = masterKey != null

    suspend fun initialize(credential: String, method: String): String = withContext(Dispatchers.IO) {
        require(credential.isNotBlank())
        require(!isConfigured()) { "La bóveda ya está configurada" }
        val master = CryptoEngine.randomBytes(32)
        val recovery = CryptoEngine.randomBytes(32)
        try {
            val wrapped = CryptoEngine.encryptBytes(master, recovery, RECOVERY_AAD)
            root.mkdirs()
            FileOutputStream(recoveryEnvelopeFile).use { it.write(wrapped) }
            keyManager.saveLocalEnvelope(master, credential, method)
            masterKey = master
            CryptoEngine.toHex(recovery)
        } catch (error: Exception) {
            recoveryEnvelopeFile.delete()
            master.fill(0)
            throw error
        } finally {
            recovery.fill(0)
        }
    }

    suspend fun unlock(credential: String): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            masterKey?.fill(0)
            masterKey = keyManager.unlock(credential)
            true
        } catch (_: Exception) {
            masterKey = null
            false
        }
    }

    fun lock() {
        masterKey?.fill(0)
        masterKey = null
    }

    suspend fun changeCredential(oldCredential: String, newCredential: String, method: String) = withContext(Dispatchers.IO) {
        val master = keyManager.unlock(oldCredential)
        keyManager.saveLocalEnvelope(master, newCredential, method)
        masterKey?.fill(0)
        masterKey = master
    }

    suspend fun importMedia(uri: Uri): VaultItemEntity = withContext(Dispatchers.IO) {
        val key = requireMasterKey()
        val metadata = readSourceMetadata(uri)
        val id = UUID.randomUUID().toString()
        val fileName = "$id.y37x"
        val encryptedFile = File(vaultDirectory, fileName)
        val verifyFile = File(context.cacheDir, "y37x-verify-$id.tmp")
        try {
            val sourceHash = context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(encryptedFile).use { output ->
                    CryptoEngine.encryptStream(input, output, key, id.toByteArray(Charsets.UTF_8))
                }
            } ?: throw IllegalStateException("No se pudo leer el archivo seleccionado")

            val verifiedHash = FileInputStream(encryptedFile).use { input ->
                FileOutputStream(verifyFile).use { output ->
                    CryptoEngine.decryptStream(input, output, key, id.toByteArray(Charsets.UTF_8))
                }
            }
            require(sourceHash.contentEquals(verifiedHash)) { "La verificación del archivo no coincidió" }

            val metadataJson = JSONObject()
                .put("name", metadata.originalName)
                .put("mime", metadata.mimeType)
                .put("size", metadata.size)
                .put("video", metadata.isVideo)
                .put("date", metadata.dateAdded)
                .toString().toByteArray(Charsets.UTF_8)
            val encryptedMetadata = Base64.encodeToString(
                CryptoEngine.encryptBytes(metadataJson, key, id.toByteArray(Charsets.UTF_8)),
                Base64.NO_WRAP
            )
            val item = VaultItemEntity(id, fileName, encryptedMetadata, System.currentTimeMillis())
            dao.insert(item)
            item
        } catch (error: Exception) {
            encryptedFile.delete()
            throw error
        } finally {
            verifyFile.delete()
        }
    }

    suspend fun listItems(): List<Pair<VaultItemEntity, VaultItemMetadata>> = withContext(Dispatchers.IO) {
        val key = requireMasterKey()
        dao.getAll().map { item -> item to decryptMetadata(item, key) }
    }

    suspend fun itemById(id: String): Pair<VaultItemEntity, VaultItemMetadata>? = withContext(Dispatchers.IO) {
        val key = requireMasterKey()
        dao.getAll().firstOrNull { it.id == id }?.let { it to decryptMetadata(it, key) }
    }

    suspend fun decryptPreview(id: String): File = withContext(Dispatchers.IO) {
        val key = requireMasterKey()
        val item = dao.getAll().firstOrNull { it.id == id } ?: throw IllegalArgumentException("Archivo no encontrado")
        val metadata = decryptMetadata(item, key)
        val extension = metadata.originalName.substringAfterLast('.', "bin").take(8).filter { it.isLetterOrDigit() }
        val preview = File(context.cacheDir, "y37x-preview-$id.$extension")
        try {
            FileInputStream(File(vaultDirectory, item.fileName)).use { input ->
                FileOutputStream(preview).use { output ->
                    CryptoEngine.decryptStream(input, output, key, id.toByteArray(Charsets.UTF_8))
                }
            }
            preview
        } catch (error: Exception) {
            preview.delete()
            throw error
        }
    }

    suspend fun deleteItem(id: String) = withContext(Dispatchers.IO) {
        val item = dao.getAll().firstOrNull { it.id == id } ?: return@withContext
        File(vaultDirectory, item.fileName).delete()
        dao.delete(id)
    }

    suspend fun restoreBackup(uri: Uri, recoveryKeyHex: String, newCredential: String, method: String) = withContext(Dispatchers.IO) {
        require(dao.getAll().isEmpty()) { "Para restaurar, la bóveda actual debe estar vacía" }
        require(method == "PIN" || method == "PATRÓN") { "Método de autenticación no válido" }
        require(if (method == "PIN") newCredential.length >= 6 && newCredential.all(Char::isDigit) else newCredential.split('-').distinct().size >= 4) {
            "La nueva credencial no cumple los requisitos"
        }
        val recoveryKey = CryptoEngine.fromHex(recoveryKeyHex.trim())
        val staging = File(context.cacheDir, "y37x-restore-${UUID.randomUUID()}").apply { mkdirs() }
        val installed = mutableListOf<File>()
        var restoredMaster: ByteArray? = null
        try {
            val manifestFile = File(staging, "manifest.json")
            context.contentResolver.openInputStream(uri)?.use { raw ->
                java.util.zip.ZipInputStream(raw).use { zip ->
                    var totalBytes = 0L
                    var entryCount = 0
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        entryCount++
                        require(entryCount <= 10_001) { "La copia contiene demasiados elementos" }
                        val safeName = entry.name
                        require(!safeName.startsWith("/") && !safeName.contains("..") && !safeName.contains('\\')) {
                            "La copia contiene una ruta no válida"
                        }
                        val destination = when {
                            safeName == "manifest.json" -> manifestFile
                            safeName.startsWith("files/") && safeName.removePrefix("files/").matches(Regex("[A-Za-z0-9-]+\\.y37x")) ->
                                File(staging, safeName.removePrefix("files/"))
                            else -> throw IllegalArgumentException("La copia contiene un elemento no reconocido")
                        }
                        require(!destination.exists()) { "La copia contiene elementos duplicados" }
                        destination.parentFile?.mkdirs()
                        var entryBytes = 0L
                        val buffer = ByteArray(64 * 1024)
                        FileOutputStream(destination).use { output ->
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                if (count == 0) continue
                                entryBytes += count
                                totalBytes += count
                                val entryLimit = if (safeName == "manifest.json") 10L * 1024L * 1024L else 2L * 1024L * 1024L * 1024L
                                require(entryBytes <= entryLimit) { "Un archivo de la copia supera el límite permitido" }
                                require(totalBytes <= 20L * 1024L * 1024L * 1024L) { "La copia supera el límite total permitido" }
                                output.write(buffer, 0, count)
                            }
                        }
                        zip.closeEntry()
                    }
                }
            } ?: throw IllegalStateException("No se pudo abrir la copia")

            require(manifestFile.exists()) { "La copia no contiene un manifiesto" }
            require(manifestFile.length() <= 10L * 1024L * 1024L) { "El manifiesto es demasiado grande" }
            val manifest = JSONObject(manifestFile.readText(Charsets.UTF_8))
            require(manifest.getInt("schema") == 1) { "Versión de copia no compatible" }
            val recoveryEnvelope = Base64.decode(manifest.getString("recoveryEnvelope"), Base64.NO_WRAP)
            val master = CryptoEngine.decryptBytes(recoveryEnvelope, recoveryKey, RECOVERY_AAD)
            restoredMaster = master
            require(master.size == 32) { "Clave maestra inválida" }
            val jsonItems = manifest.getJSONArray("items")
            require(jsonItems.length() <= 10_000) { "La copia contiene demasiados archivos" }
            val stagedFiles = staging.listFiles()?.count { it.name.endsWith(".y37x") } ?: 0
            require(stagedFiles == jsonItems.length()) { "La copia contiene archivos faltantes o inesperados" }
            val restoredItems = ArrayList<VaultItemEntity>(jsonItems.length())

            for (index in 0 until jsonItems.length()) {
                val row = jsonItems.getJSONObject(index)
                val id = row.getString("id")
                val fileName = row.getString("fileName")
                require(id.matches(Regex("[A-Za-z0-9-]{10,64}")))
                require(fileName == "$id.y37x")
                val stagedFile = File(staging, fileName)
                require(stagedFile.exists()) { "Falta un archivo de la copia" }
                val metadataEncoded = row.getString("encryptedMetadata")
                val metadataBytes = Base64.decode(metadataEncoded, Base64.NO_WRAP)
                val metadataPlain = CryptoEngine.decryptBytes(metadataBytes, master, id.toByteArray(Charsets.UTF_8))
                JSONObject(metadataPlain.toString(Charsets.UTF_8)) // validate encrypted metadata before installation

                val verify = File(staging, "verify-$id.tmp")
                try {
                    FileInputStream(stagedFile).use { input ->
                        FileOutputStream(verify).use { output ->
                            CryptoEngine.decryptStream(input, output, master, id.toByteArray(Charsets.UTF_8))
                        }
                    }
                } finally {
                    verify.delete()
                }
                val destination = File(vaultDirectory, fileName)
                stagedFile.copyTo(destination, overwrite = false)
                installed += destination
                restoredItems += VaultItemEntity(
                    id = id,
                    fileName = fileName,
                    encryptedMetadata = metadataEncoded,
                    addedAt = row.optLong("addedAt", System.currentTimeMillis())
                )
            }

            require(restoredItems.size == jsonItems.length())
            val previousLocalEnvelope = keyManager.snapshotLocalEnvelope()
            val previousRecoveryEnvelope = recoveryEnvelopeFile.takeIf { it.exists() }?.readBytes()
            try {
                recoveryEnvelopeFile.parentFile?.mkdirs()
                recoveryEnvelopeFile.writeBytes(recoveryEnvelope)
                keyManager.saveLocalEnvelope(master, newCredential, method)
                dao.insertAll(restoredItems)
                masterKey?.fill(0)
                masterKey = master
                restoredMaster = null
            } catch (error: Exception) {
                dao.deleteAll()
                keyManager.restoreLocalEnvelope(previousLocalEnvelope)
                if (previousRecoveryEnvelope == null) recoveryEnvelopeFile.delete()
                else recoveryEnvelopeFile.writeBytes(previousRecoveryEnvelope)
                throw error
            }
        } catch (error: Exception) {
            installed.forEach { it.delete() }
            throw error
        } finally {
            recoveryKey.fill(0)
            restoredMaster?.fill(0)
            staging.deleteRecursively()
        }
    }

    suspend fun hasItems(): Boolean = withContext(Dispatchers.IO) { dao.getAll().isNotEmpty() }

    private fun requireMasterKey(): ByteArray = masterKey ?: throw IllegalStateException("Desbloquea la bóveda para continuar")

    private fun decryptMetadata(item: VaultItemEntity, key: ByteArray): VaultItemMetadata {
        val encrypted = Base64.decode(item.encryptedMetadata, Base64.NO_WRAP)
        val plain = CryptoEngine.decryptBytes(encrypted, key, item.id.toByteArray(Charsets.UTF_8))
        val json = JSONObject(plain.toString(Charsets.UTF_8))
        return VaultItemMetadata(
            originalName = json.getString("name"),
            mimeType = json.getString("mime"),
            size = json.getLong("size"),
            isVideo = json.getBoolean("video"),
            dateAdded = json.getLong("date")
        )
    }

    private fun readSourceMetadata(uri: Uri): VaultItemMetadata {
        var name = "archivo"
        var size = 0L
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
        val isVideo = mime.startsWith("video/")
        return VaultItemMetadata(name, mime, size, isVideo, System.currentTimeMillis() / 1000)
    }

    companion object {
        private val RECOVERY_AAD = "y37x-recovery-master-v1".toByteArray(Charsets.UTF_8)
    }
}
