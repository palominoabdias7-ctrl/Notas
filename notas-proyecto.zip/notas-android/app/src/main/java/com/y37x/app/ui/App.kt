package com.y37x.app.ui

import android.net.Uri
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Collections
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.y37x.app.vault.VaultRepository

@Composable
fun PrivateGalleryApp(vault: VaultRepository) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("y37x_app", android.content.Context.MODE_PRIVATE) }
    val startDestination = "home"
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: "home"
    var privacyRefresh by remember { mutableIntStateOf(0) }
    val rootRoutes = setOf("home", "photos", "videos", "privacy", "settings")

    Scaffold(
        containerColor = Y37xBackground,
        bottomBar = {
            if (route in rootRoutes) {
                NavigationBar(containerColor = Y37xPanel, contentColor = Y37xText) {
                    val items = listOf(
                        Triple("home", "Inicio", Icons.Outlined.Home),
                        Triple("photos", "Fotos", Icons.Outlined.Collections),
                        Triple("videos", "Videos", Icons.Outlined.VideoLibrary),
                        Triple("privacy", "Privacidad", Icons.Outlined.Lock),
                        Triple("settings", "Ajustes", Icons.Outlined.Settings)
                    )
                    items.forEach { (destination, label, icon) ->
                        NavigationBarItem(
                            selected = route == destination,
                            onClick = {
                                navController.navigate(destination) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(padding)
        ) {
            composable("welcome") {
                WelcomeScreen {
                    prefs.edit().putBoolean("welcome_seen", true).apply()
                    navController.navigate("home") { popUpTo("welcome") { inclusive = true } }
                }
            }
            composable("home") {
                HomeScreen(
                    onNavigate = { navController.navigate(it) },
                    onOpenPrivacy = { navController.navigate("privacy") }
                )
            }
            composable("photos") {
                GalleryScreen(
                    isVideo = false,
                    vault = vault,
                    onOpen = { item -> navController.navigate("viewer/${Uri.encode(item.uri.toString())}/false") },
                    onNeedPrivacy = { navController.navigate("privacy") }
                )
            }
            composable("videos") {
                GalleryScreen(
                    isVideo = true,
                    vault = vault,
                    onOpen = { item -> navController.navigate("viewer/${Uri.encode(item.uri.toString())}/true") },
                    onNeedPrivacy = { navController.navigate("privacy") }
                )
            }
            composable("privacy") {
                key(privacyRefresh) {
                    when {
                        !vault.isConfigured() -> SetupSecurityScreen(
                            vault = vault,
                            onFinished = { navController.navigate("home") { popUpTo("privacy") { inclusive = true } } }
                        )
                        !vault.isUnlocked() -> UnlockScreen(
                            vault = vault,
                            onUnlocked = { privacyRefresh++ }
                        )
                        else -> VaultScreen(
                            vault = vault,
                            onOpen = { id -> navController.navigate("private-viewer/$id") },
                            onLock = {
                                vault.lock()
                                privacyRefresh++
                                navController.navigate("home")
                            },
                            onBackups = { navController.navigate("backups") }
                        )
                    }
                }
            }
            composable("settings") {
                SettingsScreen(
                    isConfigured = vault.isConfigured(),
                    onBackups = { navController.navigate("backups") },
                    onChangeSecurity = { navController.navigate("change-security") },
                    onAbout = { navController.navigate("about") },
                    onLock = {
                        vault.lock()
                        privacyRefresh++
                    }
                )
            }
            composable("backups") {
                BackupScreen(vault = vault, onBack = { navController.popBackStack() })
            }
            composable("about") { AboutScreen(onBack = { navController.popBackStack() }) }
            composable("change-security") {
                ChangeSecurityScreen(vault = vault, onDone = {
                    privacyRefresh++
                    navController.popBackStack()
                }, onBack = { navController.popBackStack() })
            }
            composable(
                route = "viewer/{encodedUri}/{isVideo}",
                arguments = listOf(
                    navArgument("encodedUri") { type = NavType.StringType },
                    navArgument("isVideo") { type = NavType.BoolType }
                )
            ) { entry ->
                val encoded = entry.arguments?.getString("encodedUri").orEmpty()
                val uri = Uri.parse(encoded)
                val video = entry.arguments?.getBoolean("isVideo") ?: false
                MediaViewerScreen(uri = uri, isVideo = video, onBack = { navController.popBackStack() })
            }
            composable("private-viewer/{id}") { entry ->
                PrivateViewerScreen(
                    vault = vault,
                    id = entry.arguments?.getString("id").orEmpty(),
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
