package com.y37x.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Collections
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Y37xBackground).padding(28.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BrandMark(size = 92)
            Spacer(Modifier.height(24.dp))
            Text("y37x", style = MaterialTheme.typography.displayMedium, color = Y37xText, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text("Tus recuerdos. Bajo tu control.", color = Y37xGreen, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(16.dp))
            Text(
                "Organiza fotos y videos, y protege lo que quieras mantener privado con cifrado local.",
                color = Y37xMuted,
                style = MaterialTheme.typography.bodyLarge
            )
            Spacer(Modifier.height(38.dp))
            PrimaryButton("Comenzar", onContinue)
            Spacer(Modifier.height(14.dp))
            Text("La bóveda no envía tus archivos sin tu autorización.", color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun HomeScreen(onNavigate: (String) -> Unit, onOpenPrivacy: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Y37xBackground),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BrandMark(size = 48)
                Column(Modifier.padding(start = 12.dp)) {
                    Text("y37x", style = MaterialTheme.typography.headlineMedium, color = Y37xText, fontWeight = FontWeight.Bold)
                    Text("Galería privada", color = Y37xMuted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            Text("Tu espacio", style = MaterialTheme.typography.titleLarge, color = Y37xText, fontWeight = FontWeight.Bold)
            Text("Accede rápidamente a tus archivos", color = Y37xMuted)
        }
        item { FeatureCard("Fotografías", "Explora JPG, JPEG y PNG", Icons.Outlined.Collections, "photos") { onNavigate("photos") } }
        item { FeatureCard("Videos", "Reproduce tus videos en la aplicación", Icons.Outlined.VideoLibrary, "videos") { onNavigate("videos") } }
        item { FeatureCard("PRIVACIDAD", "Bóveda cifrada con PIN o patrón", Icons.Outlined.Lock, "privacy", highlighted = true, onClick = onOpenPrivacy) }
        item { FeatureCard("Copias de seguridad", "Crea y programa respaldos cifrados", Icons.Outlined.CloudUpload, "backups") { onNavigate("backups") } }
        item {
            Text("Privacidad primero", color = Y37xGreen, fontWeight = FontWeight.SemiBold)
            Text("Los archivos de la bóveda se guardan cifrados en el almacenamiento privado de la aplicación. Las copias contienen archivos cifrados, nunca medios en claro.", color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun FeatureCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    route: String,
    highlighted: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick?.invoke() },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = if (highlighted) Y37xDarkGreen else Y37xPanel)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).background(if (highlighted) Y37xGreen.copy(alpha = 0.14f) else Y37xCard, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, contentDescription = null, tint = Y37xGreen) }
            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                Text(title, color = Y37xText, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
            }
            Text("›", color = Y37xGreen, style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@Composable
fun SettingsScreen(
    isConfigured: Boolean,
    onBackups: () -> Unit,
    onChangeSecurity: () -> Unit,
    onAbout: () -> Unit,
    onLock: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Y37xBackground)) {
        ScreenHeader("Configuración", "Seguridad y preferencias")
        SettingRow("Copias de seguridad", "Google Drive o proveedor de archivos", Icons.Outlined.CloudUpload, onBackups)
        if (isConfigured) SettingRow("Cambiar PIN o patrón", "Actualiza el método de desbloqueo", Icons.Outlined.Lock, onChangeSecurity)
        SettingRow("Bloquear bóveda", "Cierra la sesión privada de este dispositivo", Icons.Outlined.Lock, onLock)
        SettingRow("Información de y37x", "Versión y detalles de seguridad", Icons.Outlined.Info, onAbout)
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Y37xGreen, modifier = Modifier.size(25.dp))
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(title, color = Y37xText, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
        }
        Text("›", color = Y37xGreen, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Y37xBackground)) {
        ScreenHeader("Acerca de y37x", "Versión 1.0.0", onBack)
        Column(Modifier.padding(22.dp)) {
            BrandMark(size = 62)
            Spacer(Modifier.height(18.dp))
            Text("y37x", style = MaterialTheme.typography.headlineLarge, color = Y37xText, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("Galería multimedia y bóveda privada para Android.", color = Y37xMuted)
            Spacer(Modifier.height(18.dp))
            Text("Seguridad", color = Y37xGreen, fontWeight = FontWeight.Bold)
            Text("Los elementos privados se cifran con AES-256-GCM. La clave maestra se protege localmente con Android Keystore y una credencial derivada mediante PBKDF2-HMAC-SHA256.", color = Y37xMuted)
            Spacer(Modifier.height(12.dp))
            Text("Recuperación", color = Y37xGreen, fontWeight = FontWeight.Bold)
            Text("La restauración requiere una copia cifrada y la clave de recuperación independiente. Si se pierde esa clave y no existe otra copia válida, los archivos no se pueden descifrar.", color = Y37xMuted)
        }
    }
}
