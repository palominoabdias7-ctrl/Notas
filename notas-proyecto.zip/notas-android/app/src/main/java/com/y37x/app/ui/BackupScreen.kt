package com.y37x.app.ui

import android.content.Context
import android.app.Activity
import android.view.WindowManager
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.y37x.app.Y37xApplication
import com.y37x.app.backup.BackupManager
import com.y37x.app.backup.VaultBackupWorker
import com.y37x.app.security.CryptoEngine
import com.y37x.app.vault.VaultRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
fun BackupScreen(vault: VaultRepository, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(BackupManager.PREFS, Context.MODE_PRIVATE) }
    var treeUri by remember { mutableStateOf(prefs.getString(BackupManager.TREE_URI, null)) }
    var lastBackup by remember { mutableStateOf(prefs.getLong(BackupManager.LAST_BACKUP, 0L)) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var restoreUri by remember { mutableStateOf<Uri?>(null) }
    var showRestore by remember { mutableStateOf(false) }
    var recoveryKey by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var autoEnabled by remember { mutableStateOf(treeUri != null) }
    val scope = rememberCoroutineScope()
    val activity = context.findActivity()
    DisposableEffect(activity, showRestore) {
        if (showRestore) activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { if (showRestore) activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    LaunchedEffect(treeUri, vault.isConfigured()) {
        if (treeUri != null && vault.isConfigured()) VaultBackupWorker.schedule(context)
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            treeUri = uri.toString()
            prefs.edit().putString(BackupManager.TREE_URI, uri.toString()).apply()
            autoEnabled = true
            VaultBackupWorker.schedule(context)
            status = "Destino guardado. Se programó una copia cifrada cada 24 horas."
            VaultBackupWorker.runNow(context)
        }
    }
    val restorePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            restoreUri = uri
            showRestore = true
        }
    }

    Column(Modifier.fillMaxSize().background(Y37xBackground)) {
        ScreenHeader("Copias de seguridad", "Respaldo cifrado y recuperación", onBack)
        Column(Modifier.padding(horizontal = 22.dp)) {
            Text("Google Drive", color = Y37xGreen, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Elige una carpeta en el selector del sistema. Si seleccionas Google Drive, Android gestionará el acceso autorizado a tu cuenta. y37x subirá únicamente el archivo ZIP cifrado.", color = Y37xMuted)
            Spacer(Modifier.height(16.dp))
            PrimaryButton("Elegir carpeta de respaldo", onClick = { folderPicker.launch(null) })
            Spacer(Modifier.height(10.dp))
            PrimaryButton("Crear copia ahora", onClick = {
                if (treeUri == null) folderPicker.launch(null)
                else {
                    VaultBackupWorker.runNow(context)
                    status = "Copia solicitada. Se publicará cuando termine el proceso en segundo plano."
                }
            }, enabled = vault.isConfigured())
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = autoEnabled, onCheckedChange = { enabled ->
                    autoEnabled = enabled
                    if (enabled) {
                        if (treeUri == null) folderPicker.launch(null) else VaultBackupWorker.schedule(context)
                    } else {
                        VaultBackupWorker.cancel(context)
                        prefs.edit().remove(BackupManager.TREE_URI).apply()
                        treeUri = null
                    }
                }, enabled = vault.isConfigured())
                Text("Copias automáticas cada 24 horas", color = Y37xText)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (lastBackup > 0) "Última copia: ${DateFormat.getDateTimeInstance().format(Date(lastBackup))}"
                else "Última copia: todavía no se ha registrado ninguna",
                color = Y37xMuted,
                style = MaterialTheme.typography.bodySmall
            )
            Text(if (treeUri != null) "Destino configurado" else "No hay una carpeta de respaldo configurada", color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(24.dp))
            Text("Recuperar bóveda", color = Y37xGreen, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Selecciona un archivo y37x-backup.zip y proporciona la clave de recuperación de 64 caracteres. Después podrás definir un PIN nuevo.", color = Y37xMuted)
            Spacer(Modifier.height(12.dp))
            PrimaryButton("Seleccionar copia para restaurar", onClick = { restorePicker.launch(arrayOf("application/zip", "application/octet-stream")) })
            Spacer(Modifier.height(12.dp))
            Text("La restauración se rechaza si la bóveda local ya contiene archivos. No se sobrescriben datos existentes.", color = Y37xMuted, style = MaterialTheme.typography.bodySmall)
            if (busy) CircularProgressIndicator(color = Y37xGreen, modifier = Modifier.padding(12.dp))
            if (status.isNotBlank()) Text(status, color = Y37xGreen, modifier = Modifier.padding(top = 14.dp))
        }
    }

    if (showRestore && restoreUri != null) {
        AlertDialog(
            onDismissRequest = { showRestore = false; recoveryKey = ""; newPin = ""; confirmPin = "" },
            title = { Text("Restaurar bóveda") },
            text = {
                Column {
                    Text("Clave de recuperación (64 caracteres hexadecimales)")
                    OutlinedTextField(
                        value = recoveryKey,
                        onValueChange = { if (it.length <= 64) recoveryKey = it.trim() },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Nuevo PIN (mínimo 6 dígitos)")
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { if (it.length <= 12 && it.all(Char::isDigit)) newPin = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = confirmPin,
                        onValueChange = { if (it.length <= 12 && it.all(Char::isDigit)) confirmPin = it },
                        label = { Text("Repetir PIN") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !busy && recoveryKey.length == 64 && newPin.length >= 6 && newPin == confirmPin,
                    onClick = {
                        busy = true
                        showRestore = false
                        val uri = restoreUri!!
                        scope.launch {
                            val result = runCatching {
                                vault.restoreBackup(uri, recoveryKey, newPin, "PIN")
                            }
                            status = result.fold(
                                onSuccess = { "Bóveda restaurada y protegida con el nuevo PIN." },
                                onFailure = { it.message ?: "No se pudo restaurar la copia" }
                            )
                            recoveryKey = ""
                            newPin = ""
                            confirmPin = ""
                            busy = false
                        }
                    }
                ) { Text("Restaurar", color = Y37xGreen) }
            },
            dismissButton = { TextButton(onClick = { showRestore = false; recoveryKey = ""; newPin = ""; confirmPin = "" }) { Text("Cancelar") } }
        )
    }
}
