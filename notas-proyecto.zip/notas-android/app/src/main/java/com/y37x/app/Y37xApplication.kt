package com.y37x.app

import android.app.Application
import androidx.room.Room
import com.y37x.app.data.VaultDatabase
import com.y37x.app.security.KeyManager
import com.y37x.app.vault.VaultRepository

class Y37xApplication : Application() {
    lateinit var database: VaultDatabase
        private set
    lateinit var vault: VaultRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(this, VaultDatabase::class.java, "y37x-vault.db").build()
        vault = VaultRepository(this, database.vaultDao(), KeyManager(this))
    }
}
